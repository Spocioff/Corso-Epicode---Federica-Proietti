import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.commons.io.FileUtils;

public class Scuola {

	private ArrayList<Studente> listaStudenti;

	public Scuola(ArrayList<Studente> listaStudenti) {
		this.listaStudenti = listaStudenti;}

	public ArrayList<Studente> getListaStudenti() {
		return listaStudenti;}

	public void setListaStudenti(ArrayList<Studente> listaStudenti) {
		this.listaStudenti = listaStudenti;}
	
	public void getPromossi() {
		for(Studente studente : this.listaStudenti) {
			if (studente.promosso() == true) {
				System.out.println(studente.toString());
			}
		}
	}
	
	public void getStudenti() {
		for(Studente studente : this.listaStudenti) {
			System.out.println(studente.toString());
		}
	}
	
	public void getStudenteMigliore() {
		double mediaPiuAlta = 0;
		Studente studenteMigliore = null;
		for(Studente studente : this.listaStudenti) {
			if(studente.mediaStudente() > mediaPiuAlta) {
				mediaPiuAlta = studente.mediaStudente();
				studenteMigliore = studente;
			}
		} System.out.println(studenteMigliore.toString());
	}
	
	@SuppressWarnings("deprecation")
	public static void salvaStudente(String dir, Studente studente, boolean concatena) throws IOException {
		File file = new File(dir);
			if (!file.exists()) {
			file.createNewFile();
		}
		FileUtils.write(file, studente.toString(), concatena);
	}
}
