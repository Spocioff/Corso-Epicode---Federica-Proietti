import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;


public class Studente {

	private int id;
	private String nome;
	private String cognome;
	private char genere;
	private HashMap<String, ArrayList<Integer>> voti;

	private static int idTot = 0;

	{
		idTot++;
	}

	public Studente(String nome, String cognome, char genere) {
		this.id = idTot;
		this.nome = nome;
		this.cognome = cognome;
		this.genere = genere;
		this.voti = voti;

		voti = new HashMap<>();

		ArrayList<Integer> voti_random = new ArrayList<>();
		Random random = new Random();
		for (int n = 0; n < 4; n++) {
			String materia = null;
			switch (n) {
			case 0:
				materia = "Scienze";
				break;
			case 1:
				materia = "Storia";
				break;
			case 2:
				materia = "Matematica";
				break;
			case 3:
				materia = "Italiano";
				break;
			}

			for (int i = 0; i < 5; i++) {
				int prossimo_random = random.nextInt(9)+2;
				voti_random.add(prossimo_random);
			}
			voti.put(materia, voti_random);

		}
	}

	public int getId() {
		return id;}
	public String getNome() {
		return nome;}
	public String getCognome() {
		return cognome;}
	public char getGenere() {
		return genere;}
	public HashMap<String, ArrayList<Integer>> getVoti() {
		return voti;}
	public static int getIdTot() {
		return idTot;}
	
	public void setId(int id) {
		this.id = id;}
	public void setNome(String nome) {
		this.nome = nome;}
	public void setCognome(String cognome) {
		this.cognome = cognome;}
	public void setGenere(char genere) {
		this.genere = genere;}
	public void setVoti(HashMap<String, ArrayList<Integer>> voti) {
		this.voti = voti;}
	public static void setIdTot(int idTot) {
		Studente.idTot = idTot;}

	
	
	
	@Override
	public String toString() {
		return "Studente [id=" + id + ", nome=" + nome + ", cognome=" + cognome + ", genere=" + genere + "]";
	}

	public double mediaVoto(String materia) {
		double somma = 0;
			for(Integer voto: voti.get(materia)) {
				somma += voto;
			}
			return somma / this.voti.get(materia).size();
	}
	
	public int votoMiglioreMateria(String materia) {
		int max = this.voti.get(materia).get(0);
		for(Integer voto: this.voti.get(materia)) {
			if(max < voto) {
				max = voto;
			}
		}
		return max;
	}
	
	public boolean promosso() {
		int totInsuff = 0;
		ArrayList<String> materie = new ArrayList<>();
		materie.add("Storia");
		materie.add("Scienze");
		materie.add("Matematica");
		materie.add("Italiano");
		for(String materia: materie) {
			if (mediaVoto(materia) < 6) {
				totInsuff++;
			}
		}
			if (totInsuff >= 4) {
				return false;
			} else {
				return true;
			}
	}

	public double mediaStudente() {
		double sommaMedie = 0;
		ArrayList<String> materie = new ArrayList<>();
		materie.add("Storia");
		materie.add("Scienze");
		materie.add("Matematica");
		materie.add("Italiano");
		for(String materia : materie) {
		sommaMedie += mediaVoto(materia);
		
		} return sommaMedie / materie.size();
	} 
	
}
