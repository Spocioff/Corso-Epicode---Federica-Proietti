package it.epicode.catalogo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.catalogo.errors.GiaEsistenteException;
import it.epicode.catalogo.model.Libro;
import it.epicode.catalogo.requests.InserisciLibroRequest;
import it.epicode.catalogo.requests.ModificaLibroRequest;
import it.epicode.catalogo.services.LibroService;

/**
 * Servizi rest relativi alla classe Libro
 * @author Federica Proietti
 */
@RestController
@RequestMapping("/libri")
@Tag(name= "Catalogo Libri rest services", description ="implementazioni delle API rest dei libri" )
public class LibroController {
	
	@Autowired
	LibroService ls;
	
	/**
	 * Inserimento a DB di un libro
	 * associato ad il metodo Post
	 * @throws GiaEsistenteException 
	 * 
	 */
	@Operation (summary = "Inserisce un Libro nel DB", description = "Inserisce un Libro nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Libro inserito con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(path = "/inserisci-libro")
	public ResponseEntity inserisciLibro(@Valid @RequestBody InserisciLibroRequest request) throws GiaEsistenteException {
		if(ls.inserisciLibro(request)) {
			return ResponseEntity.ok("LIBRO INSERITO");}	
		else {return new ResponseEntity("INSERIMENTO FALLITO", HttpStatus.FAILED_DEPENDENCY);}

	}
	
	/**
	 * Elimina un libro a DB con id associato a quello passato in input
	 * associato al metodo DELETE
	 * 
	 */
	@Operation (summary = "Cancella un libro", description = "Cancella un Libro immettendo il suo id")
	@ApiResponse(responseCode = "200", description = "Libro cancellato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@DeleteMapping("/{isbn}")
	public ResponseEntity eliminaLibro(@PathVariable ("isbn") int isbn) {
		boolean trovato = ls.eliminaLibro(isbn);
		if(trovato) {
			return ResponseEntity.ok("LIBRO ELIMINATO");}
		return new ResponseEntity("LIBRO NON TROVATO", HttpStatus.NOT_FOUND);
	}
	/**
	 * Effettua un update del libro corrispondente all'id dato in input
	 * associato al metodo PUT
	 * 
	 */
	@Operation (summary = "Modifica un Libro", description = "Modifica i dati di un Libro")
	@ApiResponse(responseCode = "200", description = "Libro modificato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PutMapping("/modifica-libro/{isbn}")
	public ResponseEntity modificaLibro (@Valid @RequestBody ModificaLibroRequest request, @PathVariable int isbn) {
		boolean trovato = ls.modificaLibro(request, isbn);
		if(trovato) {
			return ResponseEntity.ok("LIBRO MODIFICATO");}
			return new ResponseEntity("LIBRO NON TROVATO", HttpStatus.NOT_FOUND);
	}
	/**
	 * Recupera tutti i libri a DB
	 * associato al metodo GET
	 * 
	 */
	@Operation (summary = "Mostra tutti i Libri", description = "Mostra tutti i Libri presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Libri visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping
	@SecurityRequirement(name = "bearerAuth")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity getAllLibri() {
		return ResponseEntity.ok(ls.getAllLibri());
	}
	/**
	 * Recupera i film a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 */
	@Operation (summary = "Cerca i Libri in base al codice univoco isbn", description = "Cerca i Libri nel DB in base al codice isbn")
	@ApiResponse(responseCode = "200", description = "Lista Libri visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/{isbn}")
	public ResponseEntity findLibroByIsbn(@PathVariable int isbn) {
		Libro l = ls.findLibroByIsbn(isbn);
		if(l== null) {
			return new ResponseEntity("LIBRO NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(l);
	}
}
