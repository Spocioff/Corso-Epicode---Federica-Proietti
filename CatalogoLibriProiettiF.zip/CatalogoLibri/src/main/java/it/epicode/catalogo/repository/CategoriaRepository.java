package it.epicode.catalogo.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.catalogo.model.Autore;
import it.epicode.catalogo.model.Categoria;


public interface CategoriaRepository extends CrudRepository<Categoria, Integer>{

}
