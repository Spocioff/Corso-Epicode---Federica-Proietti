package it.epicode.catalogo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.catalogo.errors.GestioneErroriControllerAdvice;
import it.epicode.catalogo.errors.GiaEsistenteException;
import it.epicode.catalogo.errors.NotFoundException;
import it.epicode.catalogo.model.Autore;
import it.epicode.catalogo.model.Libro;
import it.epicode.catalogo.requests.InserisciAutoreRequest;
import it.epicode.catalogo.requests.InserisciLibroRequest;
import it.epicode.catalogo.requests.ModificaAutoreRequest;
import it.epicode.catalogo.requests.ModificaLibroRequest;
import it.epicode.catalogo.services.AutoreService;
import it.epicode.catalogo.services.LibroService;

/**
 * Servizi rest relativi alla classe Autore
 * @author Federica Proietti
 */
@RestController
@RequestMapping("/autore")
@Tag(name= "Autori")

public class AutoreController {
	
	@Autowired
	AutoreService as;
	
	/**
	 * Inserimento a DB di un autore
	 * associato ad il metodo Post
	 * @throws GiaEsistenteException 
	 */
	@Operation (summary = "Inserisce un Autore nel DB", description = "Inserisce un Autore nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Autore inserito con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE, path = "/inserisci-autore")
	public ResponseEntity inserisciAutore(@Valid @RequestBody InserisciAutoreRequest request) throws GiaEsistenteException{
		if(as.inserisciAutore(request)) {
			return ResponseEntity.ok("AUTORE INSERITO");}
		else {return new ResponseEntity("INSERIMENTO FALLITO", HttpStatus.FAILED_DEPENDENCY);}

	}
	/**
	 * Elimina un autore a DB con id associato a quello passato in input
	 * associato al metodo DELETE
	 * 
	 */
	@Operation (summary = "Cancella un Autore", description = "Cancella un Autore immettendo il suo id")
	@ApiResponse(responseCode = "200", description = "Autore cancellato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@DeleteMapping("/{id_aut}")
	public ResponseEntity eliminaAutore(@PathVariable ("id_aut") int id_aut) {
		boolean trovato = as.eliminaAutore(id_aut);
		if(trovato) {
			return ResponseEntity.ok("AUTORE ELIMINATO");}
		return new ResponseEntity("AUTORE NON TROVATO", HttpStatus.NOT_FOUND);
	}
	/**
	 * Effettua un update dell'autore corrispondente all'id dato in input
	 * associato al metodo PUT
	 * @throws NotFoundException
	 */
	@Operation (summary = "Modifica un Autore", description = "Modifica i dati di un Autore")
	@ApiResponse(responseCode = "200", description = "Autore modificato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PutMapping("/modifica-autore/{id_aut}")
	public ResponseEntity modificaAutore (@Valid @RequestBody ModificaAutoreRequest request, @PathVariable int id_aut) throws NotFoundException {
		 as.modificaAutore(request, id_aut);
		 return ResponseEntity.ok("AUTORE MODIFICATO");
	}
	/**
	 * Recupera tutti gli autori a DB
	 * associato al metodo GET
	 * 
	 */
	@Operation (summary = "Mostra tutti gli Autori", description = "Mostra tutti gli Autori presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti gli Autori visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping
	public ResponseEntity getAllAutori() {
		return ResponseEntity.ok(as.getAllAutori());
	}
	/**
	 * Recupera gli autori a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 */
	@Operation (summary = "Cerca gli Autori in base all'id", description = "Cerca gli Autori nel DB in base all'id")
	@ApiResponse(responseCode = "200", description = "Lista Autori visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/{id_aut}")
	public ResponseEntity findAutoreById(@PathVariable int id_aut) {
		Autore a = as.findAutoreById(id_aut);
		if(a== null) {
			return new ResponseEntity("AUTORE NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(a);
	}
}
