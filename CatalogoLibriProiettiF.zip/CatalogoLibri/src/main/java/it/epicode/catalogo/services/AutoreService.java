package it.epicode.catalogo.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.catalogo.errors.GiaEsistenteException;
import it.epicode.catalogo.errors.NotFoundException;
import it.epicode.catalogo.model.Autore;
import it.epicode.catalogo.model.Categoria;
import it.epicode.catalogo.model.Libro;
import it.epicode.catalogo.repository.AutoreRepository;
import it.epicode.catalogo.repository.CategoriaRepository;
import it.epicode.catalogo.repository.LibroRepository;
import it.epicode.catalogo.requests.InserisciAutoreRequest;
import it.epicode.catalogo.requests.InserisciLibroRequest;
import it.epicode.catalogo.requests.ModificaAutoreRequest;
import it.epicode.catalogo.requests.ModificaLibroRequest;

@Service
public class AutoreService {

	@Autowired
	AutoreRepository ar;
	@Autowired
	CategoriaRepository cr;
	@Autowired
	LibroRepository lr;
	
	public boolean inserisciAutore(InserisciAutoreRequest request) throws GiaEsistenteException{
		if(ar.existsById(request.getId_aut())) {
            throw new GiaEsistenteException("Attenzione, l' autore è già stato inserito");

		}
		Autore a = new Autore();
		BeanUtils.copyProperties(request, a);
		ar.save(a);
		
		return true;
	}
	public boolean eliminaAutore(int id_aut) {
		if(!lr.existsById(id_aut)) {
			return false;
		}
		lr.deleteById(id_aut);
		return true;
	}
	public void modificaAutore(ModificaAutoreRequest request, int id_aut) throws NotFoundException {
		if(lr.existsById(request.getIsbn()) && ar.existsById(request.getId_aut())) {
		Autore a = new Autore();
		BeanUtils.copyProperties(request, a);
		ar.save(a);	
		}
		else { throw new NotFoundException("Autore non trovato");
		
		}
	}
	public List<Autore> getAllAutori() {
		return (List<Autore>) ar.findAll();
	}

	
	public Autore findAutoreById (int id_aut) {
		if(!lr.existsById(id_aut)) {
			return null;
		}
		return ar.findById(id_aut).get();
	}
}
	
