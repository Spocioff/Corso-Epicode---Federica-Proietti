package it.epicode.catalogo.errors;

public class GiaEsistenteException extends Exception{

	public GiaEsistenteException(String message) {
		super(message);
		
	}
	
	

}
