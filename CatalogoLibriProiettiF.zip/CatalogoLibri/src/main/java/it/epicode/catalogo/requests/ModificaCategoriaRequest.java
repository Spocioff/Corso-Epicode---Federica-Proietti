package it.epicode.catalogo.requests;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ModificaCategoriaRequest {

	private int id_cat;
	private String nome;
	private String cognome;
	private int isbn;
	
}
