package it.epicode.catalogo.impl;

public enum ERole {
	ROLE_ADMIN,
	ROLE_BUYER,
	ROLE_SELLER,
	ROLE_USER;
}
