package it.epicode.catalogo.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
/**
 * Classe entità Autore
 * @author Federica Proietti
 */

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Autore {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_aut;
	@NotBlank(message = "* questo campo è obbligatorio")
	private String nome;
	@NotBlank(message = "* questo campo è obbligatorio")
	private String cognome;
	@JsonIgnore
	@ManyToMany
	@JoinTable(name = "libri", joinColumns = @JoinColumn(name = "id_autore"), inverseJoinColumns = @JoinColumn(name = "id_libro"))
	@ToString.Exclude
    @EqualsAndHashCode.Exclude
	private List<Libro> libri = new ArrayList<Libro>();


}
