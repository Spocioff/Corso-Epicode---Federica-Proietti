package it.epicode.catalogo.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import it.epicode.catalogo.model.Autore;
import it.epicode.catalogo.model.Categoria;
import it.epicode.catalogo.model.Libro;
import it.epicode.catalogo.requests.InserisciAutoreRequest;
import it.epicode.catalogo.requests.InserisciCategoriaRequest;
import it.epicode.catalogo.requests.InserisciLibroRequest;
import it.epicode.catalogo.requests.ModificaAutoreRequest;
import it.epicode.catalogo.requests.ModificaCategoriaRequest;
import it.epicode.catalogo.requests.ModificaLibroRequest;
import it.epicode.catalogo.services.AutoreService;
import it.epicode.catalogo.services.CategoriaService;
import it.epicode.catalogo.services.LibroService;

/**
 * Servizi rest relativi alla classe Categoria
 * @author Federica Proietti
 */

@RestController
@RequestMapping("/categoria")
@Tag(name= "Categorie")
public class CategoriaController {
	
	@Autowired
	CategoriaService cs;
	
	/**
	 * Inserimento a DB di una categoria
	 * associato ad il metodo Post
	 * 
	 */
	@Operation (summary = "Inserisce una Categoria nel DB", description = "Inserisce una Categoria nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Categoria inserita con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(path = "/inserisci-categoria")
	public ResponseEntity inserisciCategoria(@Valid @RequestBody InserisciCategoriaRequest request) {
		if(cs.inserisciCategoria(request)) {
			return ResponseEntity.ok("CATEGORIA INSERITA");}	
		else {return new ResponseEntity("INSERIMENTO FALLITO", HttpStatus.FAILED_DEPENDENCY);}

	}
	/**
	 * Elimina una categoria a DB con id associato a quello passato in input
	 * associato al metodo DELETE
	 * 
	 */
	@Operation (summary = "Cancella una Categoria", description = "Cancella una Categoria immettendo il suo id")
	@ApiResponse(responseCode = "200", description = "Categoria cancellato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@DeleteMapping("/{id_cat}")
	public ResponseEntity eliminaCategoria(@PathVariable ("id_cat") int id_cat) {
		boolean trovato = cs.eliminaCategoria(id_cat);
		if(trovato) {
			return ResponseEntity.ok("CATEGORIA ELIMINATA");}
		return new ResponseEntity("CATEGORIA NON TROVATA", HttpStatus.NOT_FOUND);
	}
	/**
	 * Effettua un update della categoria corrispondente all'id dato in input
	 * associato al metodo PUT
	 * 
	 */
	@Operation (summary = "Modifica una Categoria", description = "Modifica i dati di una Categoria")
	@ApiResponse(responseCode = "200", description = "Categoria modificato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PutMapping("/modifica-categoria/{id_cat}")
	public ResponseEntity modificaCategoria (@Valid @RequestBody ModificaCategoriaRequest request, @PathVariable int id_cat) {
		boolean trovato = cs.modificaCategoria(request, id_cat);
		if(trovato) {
			return ResponseEntity.ok("CATEGORIA MODIFICATA");}
			return new ResponseEntity("CATEGORIA NON TROVATA", HttpStatus.NOT_FOUND);
	}
	/**
	 * Recupera tutte le categorie a DB
	 * associato al metodo GET
	 * 
	 */
	@Operation (summary = "Mostra tutte le Categorie", description = "Mostra tutte le Categorie presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutte le Categorie visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping
	public ResponseEntity getAllCategorie() {
		return ResponseEntity.ok(cs.getAllCategorie());
	}
	/**
	 * Recupera le categorie a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 */
	@Operation (summary = "Cerca le Categorie in base all'id", description = "Cerca le Categorie nel DB in base all'id")
	@ApiResponse(responseCode = "200", description = "Lista dele Categorie visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/{id_cat}")
	public ResponseEntity findCategoriaById(@PathVariable int id_cat) {
		Categoria c = cs.findCategoriaById(id_cat);
		if(c== null) {
			return new ResponseEntity("CATEGORIA NON TROVATA", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
	}
}
