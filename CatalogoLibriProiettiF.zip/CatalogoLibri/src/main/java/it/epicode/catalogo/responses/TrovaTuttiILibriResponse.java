package it.epicode.catalogo.responses;

public class TrovaTuttiILibriResponse {

}
