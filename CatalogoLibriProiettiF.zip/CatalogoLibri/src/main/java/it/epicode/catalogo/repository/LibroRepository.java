package it.epicode.catalogo.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.catalogo.model.Libro;

public interface LibroRepository extends CrudRepository<Libro, Integer>{

}
