package it.epicode.catalogo.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.catalogo.errors.GiaEsistenteException;
import it.epicode.catalogo.model.Autore;
import it.epicode.catalogo.model.Categoria;
import it.epicode.catalogo.model.Libro;
import it.epicode.catalogo.repository.AutoreRepository;
import it.epicode.catalogo.repository.CategoriaRepository;
import it.epicode.catalogo.repository.LibroRepository;
import it.epicode.catalogo.requests.InserisciLibroRequest;
import it.epicode.catalogo.requests.ModificaLibroRequest;

@Service
public class LibroService {

	@Autowired
	LibroRepository lr;
	@Autowired
	AutoreRepository ar;
	@Autowired
	CategoriaRepository cr;
	
	
	public boolean inserisciLibro(InserisciLibroRequest request) throws GiaEsistenteException {
		if(lr.existsById(request.getIsbn())){
            throw new GiaEsistenteException("Attenzione, il libro è già stato inserito");

		}
		Libro l = new Libro();
		Autore a = ar.findById(request.getId_aut()).get();
		Categoria c = cr.findById(request.getId_cat()).get();
		a.getLibri().add(l);
		l.getAutori().add(a);
		c.getLibri().add(l);
		l.getCategorie().add(c);
		BeanUtils.copyProperties(request, l);
		l.setAnnoPubblicazione(request.getAnnoPubblicazione());
		l.setPrezzo(request.getPrezzo());
		l.setTitolo(request.getTitolo());
		lr.save(l);
		return true;
	}
	public boolean eliminaLibro(int isbn) {
		if(!lr.existsById(isbn)) {
			return false;
		}
		lr.deleteById(isbn);
		return true;
	}
	public boolean modificaLibro(ModificaLibroRequest request, int isbn) {
		if(!lr.existsById(request.getIsbn()) && !ar.existsById(request.getId_aut()) && !cr.existsById(request.getId_cat())) {
			return false;
		}
		Libro l = new Libro(); 
		BeanUtils.copyProperties(request, l);
		lr.save(l);
		return true;
	}
	public List<Libro> getAllLibri() {
		return (List<Libro>) lr.findAll();
	}
	public Libro findLibroByIsbn (int isbn) {
		if(!lr.existsById(isbn)) {
			return null;
		}
		return lr.findById(isbn).get();
	}
}