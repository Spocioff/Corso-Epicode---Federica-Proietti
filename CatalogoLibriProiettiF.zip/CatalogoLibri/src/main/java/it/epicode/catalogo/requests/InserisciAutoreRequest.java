package it.epicode.catalogo.requests;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class InserisciAutoreRequest {

	private int id_aut;
	private String nome;
	private int isbn;
	
}
