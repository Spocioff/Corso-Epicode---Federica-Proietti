package it.epicode.catalogo.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.catalogo.model.Autore;
import it.epicode.catalogo.model.Categoria;
import it.epicode.catalogo.model.Libro;
import it.epicode.catalogo.repository.AutoreRepository;
import it.epicode.catalogo.repository.CategoriaRepository;
import it.epicode.catalogo.repository.LibroRepository;
import it.epicode.catalogo.requests.InserisciAutoreRequest;
import it.epicode.catalogo.requests.InserisciCategoriaRequest;
import it.epicode.catalogo.requests.ModificaCategoriaRequest;
import it.epicode.catalogo.requests.ModificaLibroRequest;

@Service
public class CategoriaService {

	@Autowired
	CategoriaRepository cr;
	@Autowired
	LibroRepository lr;
	@Autowired
	AutoreRepository ar;
	
	public boolean inserisciCategoria(InserisciCategoriaRequest request) {
		Categoria c = new Categoria();
		BeanUtils.copyProperties(request, c);
		cr.save(c);
		return true;
	}
	public boolean eliminaCategoria(int id_cat) {
		if(!cr.existsById(id_cat)) {
			return false;
		}
		cr.deleteById(id_cat);
		return true;
	}
	public boolean modificaCategoria(ModificaCategoriaRequest request, int id_cat) {
		if(!cr.existsById(request.getId_cat())) {
			return false;
		}
		Categoria c = new Categoria();
		BeanUtils.copyProperties(request, c);
		cr.save(c);
		return true;
	}
	public List<Categoria> getAllCategorie() {
		return (List<Categoria>) cr.findAll();
	}
	public Categoria findCategoriaById (int id_cat) {
		if(!cr.existsById(id_cat)) {
			return null;
		}
		return cr.findById(id_cat).get();
	}
}
