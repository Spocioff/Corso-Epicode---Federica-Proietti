package it.epicode.catalogo.requests;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class InserisciLibroRequest {

	private int isbn;
	private String titolo;
	private int annoPubblicazione;
	private double prezzo;
	private int id_cat;
	private int id_aut;
}
