package it.epicode.catalogo.impl;

import org.springframework.data.repository.CrudRepository;

public interface RoleRepository extends CrudRepository<Role, Long> {
public Role findByRoleName( ERole nomeRuolo);
}
