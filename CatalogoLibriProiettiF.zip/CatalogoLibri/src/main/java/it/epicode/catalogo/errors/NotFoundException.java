package it.epicode.catalogo.errors;

public class NotFoundException extends Exception {

	public NotFoundException(String message) {
		super(message);
		
	}

}
