package it.epicode.catalogo.runners;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.epicode.catalogo.model.Autore;
import it.epicode.catalogo.model.Categoria;
import it.epicode.catalogo.model.Libro;
import it.epicode.catalogo.repository.AutoreRepository;
import it.epicode.catalogo.repository.CategoriaRepository;
import it.epicode.catalogo.repository.LibroRepository;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Component
public class CatalogoLibriRunner implements CommandLineRunner {
	
	@Autowired
	CategoriaRepository cr;
	@Autowired
	LibroRepository lr;
	@Autowired
	AutoreRepository ar;
	
	@Override
	public void run(String... args) throws Exception {
		Autore a = Autore.builder().nome("John Ronald Reuel").cognome("Tolkien").build();        
        Categoria c = Categoria.builder().nome("Fantasy").build();
        
        Autore a2 = Autore.builder().nome("Frank").cognome("Schätzing").build();        
        Categoria c2 = Categoria.builder().nome("Fantascienza").build();
        
        Autore a3 = Autore.builder().nome("Stephen").cognome("King").build();        
        Categoria c3 = Categoria.builder().nome("Horror psicologico").build();
        
        Autore a4 = Autore.builder().nome("Haruki").cognome("Murakami").build();        
        Categoria c4 = Categoria.builder().nome("Onirico").build();
        
        Libro l = Libro.builder().titolo("Lo Hobbit").annoPubblicazione(1937).prezzo(22.50 ).build();
        l.setAutori(new ArrayList<Autore>());
        l.setCategorie(new ArrayList<Categoria>());
        
        l.getAutori().add(a);
        l.getCategorie().add(c);
        
        
        Libro l2 = Libro.builder().titolo("Il quinto giorno").annoPubblicazione(2004).prezzo(25.50).build();
        l2.setAutori(new ArrayList<Autore>());
        l2.setCategorie(new ArrayList<Categoria>());
        
        l2.getAutori().add(a2);
        l2.getCategorie().add(c2);
        
        
        Libro l3 = Libro.builder().titolo("Shining").annoPubblicazione(1977).prezzo(15.50).build();
        l3.setAutori(new ArrayList<Autore>());
        l3.setCategorie(new ArrayList<Categoria>());
        
        l3.getAutori().add(a3);
        l3.getCategorie().add(c3);
        
        
        Libro l4 = Libro.builder().titolo("Kafka sulla spiaggia").annoPubblicazione(2002).prezzo(22.90).build();
        l4.setAutori(new ArrayList<Autore>());
        l4.setCategorie(new ArrayList<Categoria>());
        
        l4.getAutori().add(a4);
        l4.getCategorie().add(c4);
        
        
        
        lr.save(l);
        lr.save(l2);
        lr.save(l3);
        lr.save(l4);
        
     log.info("Libro: " + l.getIsbn()+ " "+ l.getTitolo()+ " " + l.getAnnoPubblicazione( ) + " " + l.getPrezzo() + " " + l.getAutori()+ " " + l.getCategorie());
	}
	}

 
