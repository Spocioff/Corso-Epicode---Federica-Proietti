package it.epicode.bancomat.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import jakarta.servlet.http.HttpServletResponse;
import it.epicode.bancomat.data.ConnectionFactory;
import it.epicode.bancomat.data.ContoCorrente;

public class ContocorrenteDao {
	
	public boolean esiste(int numero) {
		Connection conn = ConnectionFactory.getConnection();
		PreparedStatement ps = null;
		String query ="SELECT * FROM contocorrente WHERE numero = ?";
		try {
			 ps = conn.prepareStatement(query);
			 ps.setInt(1, numero);
			 ResultSet result = ps.executeQuery();
			 return result.next();
		} catch (SQLException e) {
			
			System.out.println("Not exist!");
			e.printStackTrace();
		} finally {
			
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { conn.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		System.out.println("Conto non trovato");
		return false;
	}
	
	public static float infoSaldo(int numero) {
		Connection conn = ConnectionFactory.getConnection();
		Statement st = null;
		String query = "SELECT saldo FROM contocorrente WHERE numero = " + numero; 

		try {
			st = conn.createStatement();
			ResultSet risultato = st.executeQuery(query);
			if(risultato.next()) {
				return risultato.getFloat("saldo");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
		try {st.close();} catch (SQLException e) { e.printStackTrace();}
		try {conn.close();} catch (SQLException e) { e.printStackTrace();}

	}
		return 0;
	}
	
	public boolean preleva(int numeroConto, float prelievo) {
		float saldo = infoSaldo(numeroConto);
		Connection conn = ConnectionFactory.getConnection();
		float saldoAttuale = saldo - prelievo;
		int i = 0;
		String query = "UPDATE contocorrente"
				+ "	SET saldo = " + saldoAttuale
				+ "	WHERE numero =" + numeroConto;
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(query);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Operazione non riuscita");
			e.printStackTrace();
		} 	finally {
		try {ps.close();} catch (SQLException e) { e.printStackTrace();}
		try {conn.close();} catch (SQLException e) { e.printStackTrace();}
		}
		return i > 0;

	} 
	public boolean versa(int numeroConto, float versamento) {
		float saldo = infoSaldo(numeroConto);
		Connection conn = ConnectionFactory.getConnection();
		float saldoAttuale = saldo + versamento;
		int i = 0;
		String query = "UPDATE contocorrente"
				+ "	SET saldo = " + saldoAttuale
				+ "	WHERE numero =" + numeroConto;
		PreparedStatement ps = null;
		try {
			ps = conn.prepareStatement(query);
			i = ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Operazione non riuscita");
			e.printStackTrace();
		} 	finally {
		try {ps.close();} catch (SQLException e) { e.printStackTrace();}
		try {conn.close();} catch (SQLException e) { e.printStackTrace();}
		}
		return i > 0;
	}
	public ContoCorrente getContoCorrente(int numero) {

		Connection conn = ConnectionFactory.getConnection();
		Statement st = null;
		try {
			st = conn.createStatement();
			String sql = "select * from contocorrente where numero =" + numero;
			ResultSet rs = st.executeQuery(sql);
			if (rs.next()) {
				String intestatario = rs.getString("intestatario");
				float saldo = rs.getFloat("saldo");
				ContoCorrente cc = new ContoCorrente(numero, intestatario, saldo);
				return cc;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				st.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
}
