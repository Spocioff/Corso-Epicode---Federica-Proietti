package it.epicode.bancomat.data;

import java.sql.Connection;

public class ConnectionFactory {

	public static String URL = "jdbc:postgresql://localhost:5432/bancadb";
	public static String USER = "postgres";
	public static String PASSWORD = "root";
	
	public ConnectionFactory()  {}
		
		public static Connection getConnection()  {
		Connection conn = null;
		
		try {
			Class.forName("org.postresqlDriver");
			
		}catch (ClassNotFoundException e)  {
			e.printStackTrace();
		}
		
		return conn;
		
		
		}
}
