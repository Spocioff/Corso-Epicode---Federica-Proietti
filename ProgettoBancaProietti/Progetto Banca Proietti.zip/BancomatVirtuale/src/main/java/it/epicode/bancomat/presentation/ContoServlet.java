package it.epicode.bancomat.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import it.epicode.bancomat.business.BancomatEJB;

/**
 * Servlet implementation class ContoServlet
 */
public class ContoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	BancomatEJB bejb;
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ContoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		int numero = Integer.parseInt (request.getParameter("numero"));
		String intestatario = request.getParameter("intestatario");
		float saldo = Float.parseFloat (request.getParameter("saldo"));
		String azione = request.getParameter("azione");
		float quantita = Float.parseFloat (request.getParameter("quantita"));
		String operazione = request.getParameter("operazione");

		boolean okay = false;
		String mess = "";
		switch(azione) {
		case "prelievo":
			okay = bejb.ccPreleva(operazione, numero, quantita);
			if(okay)  {
				mess = "Prelievo eseguito con successo";
			}else {
				mess = "Non � possibile eseguire questa operazione.";
			}
			break;

		case "versamento":
			okay = bejb.ccVersa(operazione, numero, quantita);
			if(okay)  {
				mess = "Versamento eseguito con successo";
			}else {
				mess = "Non � possibile eseguire operazione.";
			}
			break;	

		case "saldo":
			okay = bejb.ccInfoSaldo(operazione, numero, quantita);
			if(okay)  {
				mess = "Il saldo disponibile �:";
			}else {
				mess = "Non � possibile eseguire questa operazione.";
			}
			break;		

		}



	}}


