package it.epicode.bancomat.business;

import it.epicode.bancomat.dao.ContocorrenteDao;
import it.epicode.bancomat.data.ContoCorrente;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;

/**
 * Session Bean implementation class BancomatEJB
 */
@Stateless
@LocalBean
public class BancomatEJB {
	
	private ContocorrenteDao cc;

    /**
     * Default constructor. 
     */
    public BancomatEJB() {
    this.cc = new ContocorrenteDao();
    }
    
    public boolean controllaOperazione(String operazione, int numero, float quantita) {
    	try {
			if((operazione == "saldo" || operazione == "prelievo" || operazione =="versamento") 
					&& cc.esiste(numero) && quantita <= cc.infoSaldo(numero)) {
			}
			return true;

		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}
	
	public boolean ccEsiste(String operazione, int numero, float quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return cc.esiste(numero);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
    	return false;
    }
	
	public boolean ccPreleva(String operazione, int numero, float quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return cc.preleva(numero, quantita);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
    	return false;
    }
	
	public boolean ccVersa(String operazione, int numero, float quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return cc.versa(numero, quantita);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
    	return false;
    }
	
	public float ccInfoSaldo(String operazione, int numero, float quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return cc.infoSaldo(numero);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
		return quantita;
    	
    }
	
	public ContoCorrente nuovoContocorrente(String operazione, int numero, float quantita) {
    	try {
    	if(controllaOperazione(operazione, numero, quantita) == true){
    	}
		return cc.getContoCorrente(numero);
    	}
    	catch (Exception e) {
    	e.printStackTrace();
    	}
		return null;
	
	}

    
    public static double infoSaldo(int numero) {
    	return ContocorrenteDao.infoSaldo(numero);
    }
    
}
