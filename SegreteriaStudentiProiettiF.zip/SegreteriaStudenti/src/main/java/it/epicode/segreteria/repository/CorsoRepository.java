package it.epicode.segreteria.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.segreteria.model.Corso;


public interface CorsoRepository extends CrudRepository<Corso, String> {

}
