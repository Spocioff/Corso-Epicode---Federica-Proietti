package it.epicode.segreteria.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.ManyToAny;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.minidev.json.annotate.JsonIgnore;

@Entity
@Data
@NoArgsConstructor

/**
 * Classe che gestisce la persistenza su DB
 * Utilizza lombok per semplificare la scrittura
 * 
 * @author Federica Proietti
 */

public class Studente {
	@Id
	private String matricola;
	@NotBlank
	private String nome;
	@NotBlank
	private String cognome;
	@NotBlank
	private String dataNascita;
	@NotBlank
	private String email;
	@NotBlank
	private String citta;
	@NotBlank
	private String indirizzo;
	
	@ManyToOne
	@JoinColumn(name= "id_corso")
	@JsonIgnore
	private Corso corso;
	
}
