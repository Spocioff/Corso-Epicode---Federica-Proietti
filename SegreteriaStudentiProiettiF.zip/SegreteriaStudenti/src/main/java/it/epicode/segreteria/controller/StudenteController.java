package it.epicode.segreteria.controller;

import javax.validation.Valid;

import org.apache.catalina.startup.SetAllPropertiesRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.segreteria.model.Studente;
import it.epicode.segreteria.services.SegreteriaService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller


public class StudenteController {

	@Autowired
	SegreteriaService ss;
	
	 @GetMapping("/form-inserisci-studente")
	 public ModelAndView formInserisciStudente() {
			ModelAndView mv = new ModelAndView("form-inserisci-studente", "studente", new Studente());
			mv.addObject("listaCorsi", ss.getCorsi());
			return mv;
	 }
	 
	 @PostMapping("/post-inserisci-studente")
	 public ModelAndView postInserisciStudente(@Valid @ModelAttribute Studente studente, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.inserisciStudente(studente);
		 ModelAndView mv = new ModelAndView("redirect:/lista-studenti");
		 return mv;
	 }
	 @GetMapping("/form-modifica-studente/{matricola}")
	 public ModelAndView formModificaStudente(@PathVariable("matricola") String matricola) {
			ModelAndView mv = new ModelAndView("form-modifica-studente", "studente", ss.trovaStudente(matricola));
			mv.addObject("listaCorsi", ss.getCorsi());
			return mv;
	 }
	 @PostMapping("/post-modifica-studente")
	 public ModelAndView postmodificaStudente(@Valid @ModelAttribute Studente studente, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.modificaStudente(studente);
		 ModelAndView mv = new ModelAndView("redirect:/lista-studenti");
		 return mv;
	 
	 }
	 @GetMapping("/form-elimina-studente/{matricola}")
	 public ModelAndView formEliminaStudente(@PathVariable("matricola") String matricola) {
		 ModelAndView mv = new ModelAndView("form-elimina-studente", "studente", ss.trovaStudente(matricola));
		 mv.addObject("listaStudenti", ss.getStudenti());
			return mv;
		 
	 }
	 @GetMapping("/post-elimina-studente")
	 public ModelAndView eliminaStudente(@ModelAttribute Studente studente, BindingResult result) {
		 if(result.hasErrors()) {
			 return new ModelAndView("error", HttpStatus.BAD_REQUEST);
		 }
		 ss.eliminaStudente(studente);
		 ModelAndView mv = new ModelAndView("redirect:/lista-studenti");
		 log.info(studente.toString());
		 return mv;
	 }
	 }
	
