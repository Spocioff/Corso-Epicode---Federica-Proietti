package it.epicode.segreteria.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import it.epicode.segreteria.repository.StudenteRepository;

@Component
public class StudenteRunner implements CommandLineRunner {

	@Autowired
	StudenteRepository sr;

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}
}
