package it.epicode.segreteria.repository;

import org.springframework.data.repository.CrudRepository;

import it.epicode.segreteria.model.Studente;

public interface StudenteRepository extends CrudRepository<Studente, String> {

}
