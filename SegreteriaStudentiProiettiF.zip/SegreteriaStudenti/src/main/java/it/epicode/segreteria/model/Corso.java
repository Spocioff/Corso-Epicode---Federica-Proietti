package it.epicode.segreteria.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import net.minidev.json.annotate.JsonIgnore;

@Entity
@Data
@NoArgsConstructor

/**
 * Classe che gestisce la persistenza su DB
 * Utilizza lombok per semplificare la scrittura
 * 
 * @author Federica Proietti
 */
public class Corso {
	@Id
	private String id;
	@NotBlank
	private String nomeCorso;
	private String indirizzo;
	
	@Min(value= 10, message= "Il numero di esami del corso deve essere minimo 10")
	private int numeroEsami;
	@OneToMany(mappedBy = "corso")
	@JsonIgnore
	@ToString.Exclude
	private List<Studente> studenti;

}
