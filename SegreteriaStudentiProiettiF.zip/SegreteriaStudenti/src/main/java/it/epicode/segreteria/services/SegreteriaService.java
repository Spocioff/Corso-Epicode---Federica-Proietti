package it.epicode.segreteria.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.epicode.segreteria.model.Corso;
import it.epicode.segreteria.model.Studente;
import it.epicode.segreteria.repository.CorsoRepository;
import it.epicode.segreteria.repository.StudenteRepository;

@Service
public class SegreteriaService {
	
	@Autowired
	CorsoRepository cr;
	@Autowired
	StudenteRepository sr;
	
	public List<Studente> getStudenti() {
		sr.findAll().forEach(s->System.out.println(s.getCorso().getNomeCorso()));
        return (List<Studente>) sr.findAll();
    }
    
    public List<Corso> getCorsi() {
        return (List<Corso>) cr.findAll();
    }
    
    public void inserisciStudente(Studente studente) {
    	if(!sr.existsById(studente.getMatricola())) {
    		sr.save(studente);
    	}
    }
    public void inserisciCorso(Corso corso) {
    	if(!cr.existsById(corso.getId())) {
    		cr.save(corso);
    	}
    }
    public void modificaStudente(Studente studente) {
    	if(sr.existsById(studente.getMatricola())) {
    		sr.findById(studente.getMatricola()).get();
    		sr.save(studente);
    	}
    }
    public Studente trovaStudente (String matricola) {
    	if(sr.existsById(matricola)) {
    		Studente studente= sr.findById(matricola).get();
    		return studente;
    	}
    	return new Studente();
    }
    public void eliminaStudente (Studente studente) {
    	if(sr.existsById(studente.getMatricola())) {
    		sr.findById(studente.getMatricola()).get();
    		sr.delete(studente);

    		
    	}
    }
    public void modificaCorso(Corso corso) {
    	if(cr.existsById(corso.getId())) {
    		cr.findById(corso.getId()).get();
    		cr.save(corso);
    	}
    }
    public Corso trovaCorso (String id) {
    	if(cr.existsById(id)) {
    		Corso corso= cr.findById(id).get();
    		return corso;
    	}
    	return new Corso();
    }
    public void eliminaCorso (Corso corso) {
    	if(cr.existsById(corso.getId())) {
    		cr.findById(corso.getId()).get();
    		cr.delete(corso);

    		
    	}
    }
}
