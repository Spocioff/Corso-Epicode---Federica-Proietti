package it.epicode.segreteria.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import it.epicode.segreteria.services.SegreteriaService;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Controller
public class SegreteriaController {
	
	@Autowired
	SegreteriaService ss;
	
	 @GetMapping("/")
		public ModelAndView home() {
			ModelAndView mv = new ModelAndView("home-page");
			mv.addObject("titoloPagina", "Università della Vita");
			
			return mv;
	 }
	 @GetMapping("/lista-corsi")
	 public ModelAndView listaCorsi() {
			ModelAndView mv = new ModelAndView("lista-corsi");
			mv.addObject("listaCorsi", ss.getCorsi());
			return mv;
	 }
	 @GetMapping("/lista-studenti")
	 public ModelAndView listaStudenti() {
			ModelAndView mv = new ModelAndView("lista-studenti");
			mv.addObject("listaStudenti", ss.getStudenti());
			return mv;
	 }
	 
	 
}
