package portalePoliziaMunicipale;

public class Infrazione {

	private int id;
	private String data;
	private String tipo;
	private double importo;
	private String targa_auto;
	
	public Infrazione() {}



	public Infrazione(int id, String data, String tipo, double importo, String targa_auto) {
		super();
		this.id = id;
		this.data = data;
		this.tipo = tipo;
		this.importo = importo;
		this.targa_auto = targa_auto;
	}



	public Infrazione(String data, double importo, String targa_auto) {
		this.data = data;
		this.importo = importo;
		this.targa_auto = targa_auto;}

	public int getId() {
		return id;}
	public String getData() {
		return data;}
	public String getTipo() {
		return tipo;}
	public double getImporto() {
		return importo;}
	public String getTarga_auto() {
		return targa_auto;}
	public void setData(String data) {
		this.data = data;}
	public void setTipo(String tipo) {
		this.tipo = tipo;}
	public void setImporto(double importo) {
		this.importo = importo;}
	public void setTarga_auto(String targa_auto) {
		this.targa_auto = targa_auto;}
	
	
	
	
}
