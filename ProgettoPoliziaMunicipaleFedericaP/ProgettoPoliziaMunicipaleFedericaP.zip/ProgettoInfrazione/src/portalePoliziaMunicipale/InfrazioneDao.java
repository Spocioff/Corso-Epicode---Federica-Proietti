package portalePoliziaMunicipale;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import jdbc.ConnectionFactory;


public class InfrazioneDao {

	public boolean inserisciInfrazione (Infrazione infrazione) {
		Connection connessione = ConnectionFactory.getConnection();
		String query = "INSERT INTO infrazione (id, data, tipo, importo, targa_auto) VALUES (?, ?, ?, ?, ?)";
		int pippo = 0;
		PreparedStatement ps = null;
		try {
			ps = connessione.prepareStatement(query);
			ps.setInt(1, infrazione.getId());
			ps.setString(2, infrazione.getData());
			ps.setString(3, infrazione.getTipo());
			ps.setDouble(4, infrazione.getImporto());
			ps.setString(5, infrazione.getTarga_auto());

			pippo = ps.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try { ps.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		if (pippo > 0) {
			System.out.println("Infrazione inserita correttamente!");
			return true;
		}else {
			System.out.println("Nessuna Infrazione Inserita");
			return false;
			
		}
	}	

	public void stampaDatiInfrazioniAuto() {
		Connection connessione = ConnectionFactory.getConnection();
		Statement statement = null;
		try {
			statement = connessione.createStatement();
			String query = "SELECT auto.*, infrazione.id, data, tipo, importo FROM auto join infrazione on auto.targa = infrazione.targa_auto";
			System.out.println("Dati infrazione auto: ");
			System.out.println();
			ResultSet risultato = statement.executeQuery(query);
			while (risultato.next()) {
				int id_infrazione = risultato.getInt("id");
				String data_infrazione = risultato.getString("data");
				String tipo_infrazione = risultato.getString("tipo");
				double importo_infrazione = risultato.getDouble("importo");
				String targa_auto = risultato.getString("targa");
				String marca_auto = risultato.getString("marca");
				String modello_auto = risultato.getString("modello");


				System.out.println( id_infrazione + ", " + data_infrazione + ", " + tipo_infrazione + ", " + importo_infrazione + ", " + targa_auto + ", " + marca_auto + ", " + modello_auto);
			}

		} catch (SQLException e) {
			System.out.println("Errore nel metodo stampaDatiInfrazioniAuto");
			e.printStackTrace();
		}finally { 
			try { statement.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
	}
	public boolean eliminaInfrazione(int id) {
		Connection connessione = ConnectionFactory.getConnection();
		Statement statement = null;
		String query = "DELETE FROM infrazione WHERE id = " + id;

		int pluto = 0;
		try {
			statement = connessione.createStatement();

			pluto = statement.executeUpdate(query);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try { statement.close(); } catch (SQLException e) { e.printStackTrace(); }
			try { connessione.close(); } catch (SQLException e) { e.printStackTrace(); }
		}
		if (pluto > 0) {
			System.out.println("Infrazione rimossa!");
			return true;
		}
		else {
			System.out.println("Nessuna infrazione da rimuovere");
			return false;
			
		}


	}


}
//delete from infrazione where id = id_infrazione
