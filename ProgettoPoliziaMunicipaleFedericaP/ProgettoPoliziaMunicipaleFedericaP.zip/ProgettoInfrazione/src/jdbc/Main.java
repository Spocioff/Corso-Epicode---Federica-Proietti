package jdbc;
import java.util.ArrayList;
import java.util.Scanner;
import portalePoliziaMunicipale.Auto;
import portalePoliziaMunicipale.AutoDao;
import portalePoliziaMunicipale.Infrazione;
import portalePoliziaMunicipale.InfrazioneDao;

public class Main {

	public static void main(String[] args) {
		
		AutoDao auto_dao = new AutoDao();
		InfrazioneDao infr_dao = new InfrazioneDao();
		Scanner scanner = new Scanner(System.in);
	
		int ciccio = 0;
		
		System.out.println("Benvenuti nel portale della Polizia Municipale per la gestione delle infrazioni. "
				+ "\nScegliere una delle seguenti opzioni: "
				+ "\n1 - Inserisci Dati Auto "
				+ "\n2 - Inserisci Dati Infrazione "
				+ "\n3 - Visualizza Tutte Le Auto "
				+ "\n4 - Cerca Auto Da Targa "
				+ "\n5 - Visualizza Dati Infrazioni e Auto da Targa "
				+ "\n6 - Elimina Infrazione "
				+ "\n7 - Esci dal Portale "
				+ "\n8 - Crediti" );
		
		
		ciccio = scanner.nextInt();
		do { 
			
		
		switch(ciccio) {
			case 1:
				System.out.println("Inserisci Targa Auto");
				String targa = scanner.next();
				System.out.println("Inserisci Marca Auto");
				String marca = scanner.next();
				System.out.println("Inserisci Modello Auto");
				String modello = scanner.next();
				Auto auto = new Auto(targa, marca, modello);
				auto_dao.inserisciAuto(auto);
				System.out.println("Inserisci un numero per proseguire");
				ciccio = scanner.nextInt();
		
			case 2:
				System.out.println("Inserisci Dati Infrazione");
				System.out.println("Inserisci ID Infrazione");
				int id = scanner.nextInt();
				System.out.println("Inserisci Data Infrazione");
				String data = scanner.next();
				System.out.println("Inserisci Tipo Infrazione");
				String tipo = scanner.nextLine();
				tipo = scanner.nextLine();
				System.out.println("Inserisci Importo Infrazione");
				double importo = scanner.nextDouble();
				System.out.println("Inserisci Targa Auto");
				String targa_auto = scanner.next().toUpperCase();
				Infrazione infrazione = new Infrazione(id, data, tipo, importo, targa_auto);
				infr_dao.inserisciInfrazione(infrazione);
				System.out.println("Inserisci un numero per proseguire");
				ciccio = scanner.nextInt();

			case 3:
				System.out.println("Visualizza Tutte Le Auto");
				ArrayList<Auto> listaAuto = auto_dao.getAllAuto();
				System.out.println("Auto presenti nell'archivio: ");
				System.out.println();
				listaAuto.stream().forEach(autoL -> System.out.println(autoL.toString()));
				System.out.println("Inserisci un numero per proseguire");
				ciccio = scanner.nextInt();
				
			case 4:
				System.out.println("Cerca Auto Da Targa");
				System.out.println("Inserisci Targa");
				targa = scanner.next();
				System.out.println(auto_dao.cercaAuto(targa)); 
				System.out.println("Inserisci un numero per proseguire");
				ciccio = scanner.nextInt();
				
			case 5:
				System.out.println("Visualizza Dati Infrazioni e Auto da Targa");
				infr_dao.stampaDatiInfrazioniAuto();
				System.out.println("Inserisci un numero per proseguire");
				ciccio = scanner.nextInt();
				
			case 6:
				System.out.println("Elimina Infrazione");
				System.out.println("Inserisci l'ID dell'Infrazione che vuoi eliminare");
				id = scanner.nextInt();
				infr_dao.eliminaInfrazione(id);
				System.out.println("Inserisci un numero per proseguire");
				ciccio = scanner.nextInt();
				
			case 7:
				System.out.println("Sei uscito dal portale della Polizia Municipale."
						+ "\nArrivederci");
				scanner.close();
				break;
				
			case 8:
				System.out.println("Si ringrazia il maestro Marco Adriani. \nIn suo onore, alcune variabili di questo programma sono state chiamate "
						+ "\nCICCIO, "
						+ "\nPIPPO "
						+ "\ne PLUTO");
				System.out.println("Inserisci un numero per proseguire");
				ciccio = scanner.nextInt();
		   
		}
		}
		while (ciccio != 7);
		
	}

}
