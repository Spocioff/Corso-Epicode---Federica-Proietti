package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

	public static final String URL = "jdbc:postgresql://localhost:5432/multedb";
	public static final String USER = "postgres";
	public static final String PASSWORD = "Porco346!";

	public static Connection getConnection() {
		Connection connessione = null;
		try {
			connessione = DriverManager.getConnection(URL, USER, PASSWORD);
			System.out.println("Connessione effettuata correttamente");
		} catch (SQLException e) {
			System.out.println("Connessione fallita");
			e.printStackTrace();
		}
		return connessione;
	}
}
