
public class ThreadScuole extends Thread {

	private Scuola scuola;
	
	public ThreadScuole(Scuola scuola) {
		this.scuola = scuola;
	}
	@Override
	public void run() {
		for(Studente studente : scuola.getListaStudenti()) {
			System.out.println(studente.toString());
			try {
				sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	
}
