import java.io.IOException;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		Studente studente1 = new Studente("David","Gilmour" , 'M');
		Studente studente2 = new Studente("James","Hetfield" , 'M');
		Studente studente3 = new Studente("Lemmy","KilMister" , 'M');
		Studente studente4 = new Studente("Ozzy","Osbourne" , 'M');
		Studente studente5 = new Studente("Dave","Growl" , 'M');
		Studente studente6 = new Studente("Dolores","O' Riordan" , 'F');
		Studente studente7 = new Studente("Amy","Lee" , 'F');
		Studente studente8 = new Studente("Janis","Joplin" , 'F');
		Studente studente9 = new Studente("Luca","Laurenti" , 'M');
		Studente studente10 = new Studente("Andre","Dipr�" , 'M');
		
		ArrayList<Studente> classe1 = new ArrayList<>();
		ArrayList<Studente> classe2 = new ArrayList<>();
	
		
			classe1.add(studente1);
			classe1.add(studente2);
			classe1.add(studente3);
			classe1.add(studente4);
			classe1.add(studente5);
			classe2.add(studente6);
			classe2.add(studente7);
			classe2.add(studente8);
			classe2.add(studente9);
			classe2.add(studente10);

		
		Scuola scuola1 = new Scuola(classe1);
		Scuola scuola2 = new Scuola(classe2);

		ThreadScuole thread1 = new ThreadScuole(scuola1);
		ThreadScuole thread2 = new ThreadScuole(scuola2);
			thread1.start();
			thread2.start();
			
			try {
				scuola1.salvaStudente("C:\\Users\\imost\\Desktop\\JAVA Esercizi\\ListaStudenti.txt", true);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			System.out.println(studente1.promosso());
			System.out.println(studente2.mediaVoto("Scienze"));
			System.out.println(studente3.mediaStudente());
			System.out.println(studente4.votoMiglioreMateria("Matematica"));
			scuola1.getPromossi();



	}
	
	

}
