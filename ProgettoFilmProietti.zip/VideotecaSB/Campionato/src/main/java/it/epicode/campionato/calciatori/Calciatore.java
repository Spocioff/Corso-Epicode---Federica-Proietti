package it.epicode.campionato.calciatori;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor

/**
 * Classe che gestisce la persistenza su database della classe calciatore
 * 
 * 
 * @author Giovanni Guarnieri
 * 
 * 
 * 
 * 
 */

public class Calciatore {
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@NotBlank(message = "il nome del calciatore e' obbligatorio!!")
	private String nome;
	@Size(min = 5 , max = 10, message = "il cognome deve essere minimo di 5 e massimo di 10 caratteri")
	private String cognome;
	

}
