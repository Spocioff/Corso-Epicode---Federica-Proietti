package it.epicode.campionato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampionatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampionatoApplication.class, args);
	}

}
