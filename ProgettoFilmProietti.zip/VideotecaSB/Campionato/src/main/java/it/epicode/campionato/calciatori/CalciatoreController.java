package it.epicode.campionato.calciatori;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;





/**
 * servizi rest relativi alla classe calciatore
 * @author Giovanni Guarnieri
 * 
 */
@RestController
@RequestMapping("/calciatori")
@Tag(name = "Calciatori rest services", description = "implementazioni delle api rest dei calciatori")
public class CalciatoreController {
	@Autowired
	CalciatoreRepository cr ;

	/**
	 * inserimento a database di un calciatore
	 * associato ad un metodo post
	 * @param c
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Operation (summary = "Inserisce un calciatore nel db", description = "inserisce un calciatore nel db con nome cognome e data di nascita")
	@ApiResponse(responseCode = "200" , description = "Calciatore inserito con successo nel db !")
	@ApiResponse(responseCode ="500" , description = "ERRORE NEL SERVER")
	@PostMapping(path = "/inserisci1" ,produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity inserisciCalciatore(@Valid @RequestBody Calciatore c, BindingResult errori) {
		
		if(errori.hasErrors()) {
			// fatto con la lambda errori.getAllErrors().stream().map(e -> e.getDefaultMessage());
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
			
		}
		cr.save(c);
		return ResponseEntity.ok("Calciatore inserito");
	}
	/**
	 * recupera tutti i calciatori con un cognome uguale a quello passato in input nel database
	 * associato al metodo get passandi in input il cognome
	 * @param cognome
	 * @return
	 */
	@GetMapping("/cercapercognome/{cognome}")
	public ResponseEntity cercapercognome(@PathVariable("cognome") String cognome) {
		List<Calciatore> c = cr.findByCognome(cognome);
		if(c.size()>0) {
		return ResponseEntity.ok(c);
		}
		else { 
			return new ResponseEntity("nessun calciatore trovato", HttpStatus.NOT_FOUND);
		}
	}
	/**
	 * recupera tutti i calciatori presenti nel database
	 * @return
	 */
	
	
	@GetMapping("/{id}")
	public ResponseEntity cercaperid(@PathVariable("id") int id) {
		try {
			return ResponseEntity.ok(cr.findById(id).orElseThrow());
		} catch (Exception e) {
			
		
			return new ResponseEntity("calciatore non trovato", HttpStatus.NOT_FOUND);
		}
	}
	
	
	
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity tuttiICalciatori() {
		return ResponseEntity.ok(cr.findAll());
	}
	
	
	
	
	
	
	/**
	 * cancella i calciatori con l'id associato a quello passato in input
	 * associato al mapping delete
	 * @param c
	 * @return
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity cancellaCalciatore(@PathVariable ("id") int id ) {
		if(cr.existsById(id)) {
		cr.deleteById(id);

		return ResponseEntity.ok("Calciatore eliminato");}
		else {
			return  new ResponseEntity("calciatore non trovato ", HttpStatus.NOT_FOUND);
		}


	}
	/**
	 * fa un update del calciatore
	 * associato ad un metodo mapping put
	 * @param id
	 * @param c
	 * @return
	 */
	@PutMapping( produces = MediaType.TEXT_PLAIN_VALUE, path = "/modificacalciatore/{id}")
	public ResponseEntity modificaCalciatore(@Valid @PathVariable("id")int id,@RequestBody Calciatore c, BindingResult errori) {
		
		if(errori.hasErrors()) {
			// fatto con la lambda errori.getAllErrors().stream().map(e -> e.getDefaultMessage());
			List<String> descrizioneDiErrore = new ArrayList<String>();
			for(ObjectError e : errori.getAllErrors()) {
				descrizioneDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioneDiErrore , HttpStatus.BAD_REQUEST);
			
		}
		if(cr.existsById(id)) {
		cr.save(c);
		return ResponseEntity.ok("Calciatore modificato");
		}
		else {
			return new ResponseEntity("calciatore non esistente" , HttpStatus.NOT_FOUND);
		}
	}
}









