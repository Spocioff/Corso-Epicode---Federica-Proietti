package it.epicode.campionato.calciatori;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
/**
 * repository classe calciatore
 * @author Giovanni Guarnieri
 */
public interface CalciatoreRepository extends CrudRepository<Calciatore, Integer> {
	/**
	 * ricerca i calciatori per cognome dando in input il cognome
	 * 
	 * @param cognome
	 * @return una lista di calciatori con il cognome passato in input
	 */
	public List<Calciatore> findByCognome(String cognome);
	
	
	/**
	 * ricerca i calciatori per cognome e nome dando in input il cognome ed il nome
	 * 
	 * @param cognome
	 * @param nome
	 * @return lista di calciatori
	 */
	public List<Calciatore> findByCognomeAndNome(String cognome,String nome);


}
