package it.epicode.videoteca.film;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FilmRequestInserisciDTO {
	@NotBlank(message = "il campo titolo del film è obbligatorio")
	@Size(min = 3, max = 30, message = "Il titolo deve avere min 1 caratteri e max 40 caratteri")
	private String titolo;
	@NotBlank(message = "il campo anno del film è obbligatorio")
	@Size(min = 4, max = 4, message = "L'anno del film deve avere min 4 caratteri e max 4 caratteri")
	private String anno;
	@NotBlank(message = "il campo regista è obbligatorio")
	@Size(min = 3, max = 30, message = "Il nome del regista deve avere min 3 caratteri e max 40 caratteri")
	private String regista;
	@NotBlank(message = "il campo tipo è obbligatorio")
	@Size(min = 3, max = 30, message = "Il tipo del film deve avere min 4 caratteri e max 15 caratteri")
	private String tipo;
	@NotBlank(message = "il campo incasso è obbligatorio")
	private String incasso;
	private String nomeVideoteca;
	private String citta;
	private String indirizzo;
}
