package it.epicode.videoteca.film;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;



/**
 * Servizi rest relativi alla classe Film
 * @author Federica Proietti
 */
@RestController 
@RequestMapping("/film")
@Tag(name= "Film rest services", description ="implementazioni delle API rest dei film" )
public class FilmController {

	@Autowired
	FilmRepository fr;
	@Autowired
	FilmService fs;
	/**
	 * Inserimento a DB di un film 
	 * associato ad il metodo Post
	 * incasso criptato con Security Crypto
	 * @param f
	 * @param errori
	 * @return
	 */
	
	@Operation (summary = "Inserisce un film nel DB", description = "Inserisce un film nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Film inserito con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(produces = MediaType.APPLICATION_JSON_VALUE, path = "/inserisci")
	public ResponseEntity inserisciFilm (@Valid @RequestBody FilmRequestInserisciDTO dto, BindingResult errori) {
		if(errori.hasErrors()) {
			List<String> descrizioniDiErrore = new ArrayList<String>();
			for (ObjectError e : errori.getAllErrors()) {
				descrizioniDiErrore.add(e.getDefaultMessage());
			}
			return new ResponseEntity(descrizioniDiErrore , HttpStatus.BAD_REQUEST);
		}
		fs.inserisciFilm(dto);
		return ResponseEntity.ok("FILM INSERITO");
	}
	
	/**
	 * Recupera tutti i film a DB
	 * associato al metodo GET
	 * @return una lista di film 
	 */
	@Operation (summary = "Mostra tutti i film", description = "Mostra tutti i film presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i film visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity mostraTuttiIFilm () {
	return ResponseEntity.ok(fs.mostraListaFilmEVideoTeche());
	}
	/**
	 * Recupera i film a DB corrispondenti al nome del regista dato in input
	 * associato al metodo GET
	 * @param regista
	 * @return
	 */
		@Operation (summary = "Cerca i film in base al regista", description = "Cerca i film nel DB al in base regista")
		@ApiResponse(responseCode = "200", description = "Lista di tutti i film visualizzata con successo")
		@ApiResponse(responseCode = "500", description = "Errore nel server")
		@GetMapping("/{regista}")
		public ResponseEntity findByRegista (@PathVariable String regista) {
			List<Film> f = fr.findByRegista(regista);
			if(f.size()>0) {
				return ResponseEntity.ok(f);
			}else {
				return new ResponseEntity("film non trovato", HttpStatus.NOT_FOUND);

			}
		}
		/**
		 * Elimina un film a DB con id associato a quello passato in input
		 * associato al metodo DELETE
		 * @param id
		 * @return
		 */
		@Operation (summary = "Cancella un film", description = "Cancella un film immettendo il suo id")
		@ApiResponse(responseCode = "200", description = "Film cancellato con successo")
		@ApiResponse(responseCode = "500", description = "Errore nel server")
		@DeleteMapping("/{id}")
		public ResponseEntity cancellaFilm (@PathVariable ("id") int id) {
			if(fr.existsById(id)) {
			fr.deleteById(id);
			return ResponseEntity.ok("FILM CANCELLATO");}
			else {
				return new ResponseEntity("film non trovato", HttpStatus.NOT_FOUND);

			}
		}
		/**
		 * Effettua un update del film corrispondente all'id dato in input
		 * associato al metodo PUT
		 * @param id
		 * @param f
		 * @param errori
		 * @return
		 */
		@Operation (summary = "Modifica un film", description = "Modifica i dati di un film")
		@ApiResponse(responseCode = "200", description = "Film modificato con successo")
		@ApiResponse(responseCode = "500", description = "Errore nel server")
		 @PutMapping("/modificafilm/{id}")
		 public ResponseEntity modificaFilm (@Valid @PathVariable ("id") int id, @RequestBody FilmRequestModificaDTO dto, BindingResult errori) {
			 if(errori.hasErrors()) {
					List<String> descrizioniDiErrore = new ArrayList<String>();
					for (ObjectError e : errori.getAllErrors()) {
						descrizioniDiErrore.add(e.getDefaultMessage());
					}
					return new ResponseEntity(descrizioniDiErrore , HttpStatus.BAD_REQUEST);
			 }
			 if (fs.modificaFilm(id, dto)) {
				 
				 return ResponseEntity.ok("FILM MODIFICATO");
				}else {
					return new ResponseEntity("Film non esistente" , HttpStatus.NOT_FOUND);
				}
			 }
		 
}
