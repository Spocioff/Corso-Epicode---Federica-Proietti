package it.epicode.videoteca.film;




import java.util.List;

import it.epicode.videoteca.Videoteca;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class TuttiIFilmResponseDTO {
	
	private List<Film> listaFilm;
	private List<Videoteca> listaVideoteca;
	
}
