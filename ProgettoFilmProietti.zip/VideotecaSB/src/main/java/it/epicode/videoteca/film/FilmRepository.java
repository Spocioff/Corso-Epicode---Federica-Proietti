package it.epicode.videoteca.film;

import java.util.List;


import org.springframework.data.repository.CrudRepository;



/**
 * Repository classe Film
 * @author Federica Proietti
 */


public interface FilmRepository extends CrudRepository<Film, Integer> {

	/**
	 * Ricerca i film permettendo di inserire il regista da cercare
	 * @param regista
	 * @return Una lista di Film
	 */
	
	public List<Film> findByRegista (String regista);
	
	/**
	 * Ricerca i film permettendo di inserire l'id da cercare
	 * @param id
	 * @return
	 */
	
	public List<Film> findFilmById (Integer id);
}