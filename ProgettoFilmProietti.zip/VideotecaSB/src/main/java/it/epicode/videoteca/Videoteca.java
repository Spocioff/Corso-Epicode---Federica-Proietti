package it.epicode.videoteca;

//import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.OneToMany;

//import it.epicode.videoteca.film.Film;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Classe che gestisce la persistenza su DB
 * Utilizza lombok per semplificare la scrittura
 * 
 * 
 * @author Federica Proietti
 */

@Entity
@Data
@NoArgsConstructor
public class Videoteca {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String nomeVideoteca;
	private String citta;
	private String indirizzo;
//	@OneToMany(mappedBy = "videoteca")
//	private List<Film> listaFilm;
//	
}
