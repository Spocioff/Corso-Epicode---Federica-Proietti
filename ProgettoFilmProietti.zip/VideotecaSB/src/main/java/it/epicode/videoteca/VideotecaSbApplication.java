package it.epicode.videoteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideotecaSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideotecaSbApplication.class, args);
	}

}
