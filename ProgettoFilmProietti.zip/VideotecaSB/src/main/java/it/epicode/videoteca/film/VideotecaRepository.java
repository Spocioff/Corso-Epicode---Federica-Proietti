package it.epicode.videoteca.film;

import org.springframework.data.repository.CrudRepository;

import it.epicode.videoteca.Videoteca;

public interface VideotecaRepository extends CrudRepository<Videoteca, Integer> {

}
