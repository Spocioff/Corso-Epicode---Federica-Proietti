package it.epicode.videoteca.film;

//import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import it.epicode.videoteca.Videoteca;

@Service
public class FilmService {
	
	@Autowired
	FilmRepository fr;
	@Autowired
	VideotecaRepository vr;
	
	public boolean inserisciFilm(FilmRequestInserisciDTO dto) {
		String hash = BCrypt.hashpw(dto.getIncasso(),BCrypt.gensalt());
		dto.setIncasso(hash);
		Videoteca vt = new Videoteca();
		Film f = new Film();
		vt.setNomeVideoteca(dto.getNomeVideoteca());
		vt.setCitta(dto.getCitta());
		vt.setIndirizzo(dto.getIndirizzo());
//		List<Film> lf = new ArrayList<>();
//		vt.setListaFilm(lf);
		f.setTitolo(dto.getTitolo());
		f.setAnno(dto.getAnno());
		f.setTipo(dto.getTipo());
		f.setIncasso(dto.getIncasso());
		f.setRegista(dto.getRegista());
//		f.setVideoteca(vt);
//		lf.add(f);
		fr.save(f);
		vr.save(vt);
		
		return true;
		
		
	}
	public boolean modificaFilm(int id, FilmRequestModificaDTO dto) {
		if(!fr.existsById(id)) {
			return false;
		}
		String hash = BCrypt.hashpw(dto.getIncasso(),BCrypt.gensalt());
		dto.setIncasso(hash);
		Film f = fr.findById(id).get();
		f.setTitolo(dto.getTitolo());
		f.setAnno(dto.getAnno());
		f.setTipo(dto.getTipo());
		f.setIncasso(dto.getIncasso());
		f.setRegista(dto.getRegista());
		fr.save(f);
		return true;
	}
	
	public TuttiIFilmResponseDTO mostraListaFilmEVideoTeche() {
		TuttiIFilmResponseDTO dto = new TuttiIFilmResponseDTO();
		List<Film> listaFilm = (List<Film>) fr.findAll();
		List<Videoteca> listaVideoteche = (List<Videoteca>) vr.findAll();
		dto.setListaFilm(listaFilm);
		dto.setListaVideoteca(listaVideoteche);
		return dto;
		
	}
}
