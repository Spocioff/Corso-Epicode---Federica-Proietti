package it.epicode.film;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideotecaSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
