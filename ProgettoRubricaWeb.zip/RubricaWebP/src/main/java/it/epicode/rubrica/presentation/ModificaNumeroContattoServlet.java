package it.epicode.rubrica.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import it.epicode.rubrica.business.RubricaWebEJB;



/**
 * Servlet implementation class ModificaNumeroContatto
 */
public class ModificaNumeroContattoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 @EJB
	   RubricaWebEJB rejb; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ModificaNumeroContattoServlet() {}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
		String numTelefono = request.getParameter("numTelefono");
		
		rejb.modificaNumContatto(nome, cognome, email, numTelefono, numTelefono);
		
		response.getWriter()
		
			.append(nome)
			.append(cognome)
			.append(email)
			.append(numTelefono);
	}

}
