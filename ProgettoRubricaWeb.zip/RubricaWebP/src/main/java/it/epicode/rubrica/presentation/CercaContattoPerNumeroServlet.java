package it.epicode.rubrica.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import it.epicode.rubrica.business.RubricaWebEJB;
import it.epicode.rubrica.model.Contatto;

/**
 * Servlet implementation class CercaContattoPerNumeroServlet
 */
public class CercaContattoPerNumeroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	RubricaWebEJB rejb;
    public CercaContattoPerNumeroServlet() {
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		String numTelefoni = request.getParameter("numTelefoni");
		Contatto c = (Contatto) rejb.cercaContattoPerNumero(numTelefoni);
		
		if(c!=null) 
			response.getWriter()
			.append(c.getNome())
			.append(c.getCognome())
			.append(c.getEmail())
			.append((CharSequence) c.getNumTelefoni());
		else {
			response.getWriter()
			.append("Contatto non trovato");
	}
}
}
