package it.epicode.rubrica.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

import org.eclipse.persistence.internal.oxm.schema.model.List;

import it.epicode.rubrica.model.Contatto;
import it.epicode.rubrica.business.RubricaWebEJB;
/**
 * Servlet implementation class VisualizzaTuttiIContattiServlet
 */
public class VisualizzaTuttiIContattiServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   @EJB
   RubricaWebEJB rejb;
   
    public VisualizzaTuttiIContattiServlet() {
        
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		@SuppressWarnings("unchecked")
		ArrayList<Contatto> lc = (ArrayList<Contatto>) rejb.visualizzaTuttiIContatti();
		
		for(Contatto c: lc) {
			response.getWriter()
				.append("<div>")
				.append(c.getNome())
				.append(c.getCognome())
				.append(c.getEmail())
				.append("</div>");
	}
	}
	
}

