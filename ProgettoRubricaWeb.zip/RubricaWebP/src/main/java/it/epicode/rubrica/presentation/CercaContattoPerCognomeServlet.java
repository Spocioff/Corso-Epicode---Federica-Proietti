package it.epicode.rubrica.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import it.epicode.rubrica.business.RubricaWebEJB;
import it.epicode.rubrica.model.Contatto;

/**
 * Servlet implementation class CercaContattoPerCognomeServlet
 */
public class CercaContattoPerCognomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	RubricaWebEJB rejb;
    public CercaContattoPerCognomeServlet() {
       
    }

	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cognome = request.getParameter("cognome");
		Contatto c = (Contatto) rejb.trovaContattoPerCognome(cognome);
		
		if(c!=null) 
			response.getWriter()
			.append(c.getNome())
			.append(c.getCognome())
			.append(c.getEmail())
			.append((CharSequence) c.getNumTelefoni());
		else {
			response.getWriter()
			.append("Contatto non trovato");
	}

}
}