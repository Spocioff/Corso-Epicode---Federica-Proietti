package it.epicode.rubrica.presentation;

import jakarta.ejb.EJB;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

import it.epicode.rubrica.business.RubricaWebEJB;
import it.epicode.rubrica.model.NumTelefoni;

/**
 * Servlet implementation class EliminaContattoServlet
 */
public class EliminaContattoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	RubricaWebEJB rejb;    
  
    public EliminaContattoServlet() {
        
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String nome = request.getParameter("nome");
		String cognome = request.getParameter("cognome");
		String email = request.getParameter("email");
		String numTelefono1 = request.getParameter("numTelefono1");
		String numTelefono2 = request.getParameter("numTelefono2");
		ArrayList<NumTelefoni> numTelefoni = new ArrayList<NumTelefoni>();
		
		
		rejb.eliminaContatto(id, nome, cognome, email, numTelefoni);;
		
		response.getWriter()
			.append(id)
			.append(nome)
			.append(cognome)
			.append(email)
			.append(numTelefono1)
			.append(numTelefono2);
	}

}
