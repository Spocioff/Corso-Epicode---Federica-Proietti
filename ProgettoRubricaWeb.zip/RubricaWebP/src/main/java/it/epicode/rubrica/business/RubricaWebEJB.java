package it.epicode.rubrica.business;



import java.util.ArrayList;
import java.util.List;


import it.epicode.rubrica.model.Contatto;
import it.epicode.rubrica.model.NumTelefoni;
import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.Query;

/**
 * Session Bean implementation class RubricaWebEJB
 */
@Stateless
@LocalBean
public class RubricaWebEJB {
	@PersistenceContext(unitName="rubrica")
	EntityManager em;
    /**
     * Default constructor. 
     */
    public RubricaWebEJB() {
      
    }
//    public void inserisciContatto (String id, String nome, String cognome, String email, NumTelefoni numTelefono1, NumTelefoni numTelefono2) {
//    	int idN = Integer.parseInt(id);
//    	ArrayList<NumTelefoni> numTelefoni = new ArrayList<NumTelefoni>();
//		numTelefoni.add((NumTelefoni) numTelefono1);
//		numTelefoni.add((NumTelefoni) numTelefono2);
//    	Contatto c = new Contatto(idN, nome, cognome, email, numTelefoni);
//    	inserisciContatto(c);
//    }
    public void inserisciContatto(String id, String nome, String cognome, String email, String numTelefono) {
	     int idN = Integer.parseInt(id);
	 Contatto c = new Contatto(idN, nome, cognome, email, numTelefono);
  	inserisciContatto(c);
	   }
    
    
    public void inserisciContatto(Contatto c) {
    	em.persist(c);
    }
    
    
//    public void modificaNumContatto(String id, String nome, String cognome, String email, NumTelefoni num) {
//		List<NumTelefoni> lista = new ArrayList<>();
//		lista.add(num);
//		int idM = Integer.parseInt(id);
//		Contatto c = new Contatto(idM, nome, cognome, email, lista);
//		
//		
//	}
//    
//    public void modificaNumeroContatto(Contatto c) {
//    	em.merge(c);
//    }
    public void modificaNumContatto(String id, String nome, String cognome, String email, String numTelefono) {
		
		int idN = Integer.parseInt(id);
		Contatto c = new Contatto(idN, nome, cognome, email, numTelefono);
		modificaNumContatto(c);
		
	}
	public void modificaNumContatto(Contatto c) {
		em.merge(c);
	}

    
    @SuppressWarnings("unchecked")
	public List<Contatto> cercaContattoPerCognome(String cognome) {
    Query q = em.createNamedQuery("contatto.trova.per.cognome");
	q.setParameter("cognome", cognome);
	
	return q.getResultList();
    } 
    
    @SuppressWarnings("unchecked")
	public Contatto cercaContattoPerNumero (String numTelefono) {
    Query q = em.createNamedQuery("contatto.trova.per.numTelefoni");
   	q.setParameter("numTelefoni", numTelefono);
   	return (Contatto) q.getSingleResult();
    }
    public void eliminaContatto(String id, String nome, String cognome,String email, List<NumTelefoni> numTelefoni) {
    	int iId = Integer.parseInt(id);
    	Contatto c = new Contatto(iId,nome,cognome, email, numTelefoni);
    	eliminaContatto(c);
    }
    public void eliminaContatto(Contatto c) {
    	em.remove(  em.merge(c)  );
    }
    public List<Contatto> visualizzaTuttiIContatti() {
    	Query q = em.createNamedQuery("contatto.visualizza.tutti.contatti");
    	return q.getResultList();
    }
    @SuppressWarnings("unchecked")
	public List<NumTelefoni> trovaContattoPerCognome(String cognome) {
    	Query q = em.createNamedQuery("contatto.trova.per.cognome");
    	q.setParameter("cognome", cognome);
    	return  q.getResultList();
    	
    }
}
