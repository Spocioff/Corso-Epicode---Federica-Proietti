package it.epicode.energia.errors;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


import lombok.extern.slf4j.Slf4j;
/**
 * Classe di gestione degli errori centralizzata
 * si usa annotazione ExceptionHandler per gestire errori nei services e nei controller
 * @author Federica Proietti
 */
@ControllerAdvice
@Slf4j
public class GestioneErroriControllerAdvice {
	
	
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity erroriInvalidazioni(MethodArgumentNotValidException ex) {
		log.info("erroriInvalidazioni");
		List<ObjectError> le = ex.getAllErrors();
		List<String>messaggiDiErrore = new ArrayList<>();
		for(ObjectError e : le) {
			messaggiDiErrore.add(e.getDefaultMessage());
		}
		return new ResponseEntity(messaggiDiErrore ,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(GiaEsistenteException.class)
	protected ResponseEntity entitaGiaEsistente(GiaEsistenteException ex) {
		
		
		
		return new ResponseEntity(ex.getMessage(), HttpStatus.ALREADY_REPORTED);
		
		
	}

@ExceptionHandler(NotFoundException.class)
protected ResponseEntity entitaNonTrovata(NotFoundException nt) {
	
	return new ResponseEntity(nt.getMessage(), HttpStatus.NOT_FOUND);
}
	
	
	
	
	
	@ExceptionHandler(NoSuchElementException.class)
	public ResponseEntity erroriDiEsistenza(NoSuchElementException nsee) {
		
		return new ResponseEntity("si è verificato un errore" + nsee.getMessage(), HttpStatus.NOT_FOUND);
	}

	public GestioneErroriControllerAdvice() {
		log.info("GestioneErroriControllerAdvice");
	}
	
	
}
