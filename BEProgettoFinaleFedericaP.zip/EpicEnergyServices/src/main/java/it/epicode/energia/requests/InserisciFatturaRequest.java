package it.epicode.energia.requests;

import java.math.BigDecimal;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import it.epicode.energia.model.StatoFattura;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
public class InserisciFatturaRequest {

	private String partitaIva;
	private int anno; 
	private String data;
	private Double importo;
	private int numero;
	@Enumerated(EnumType.STRING)
	private StatoFattura stato;
}
