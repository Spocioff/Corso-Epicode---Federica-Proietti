package it.epicode.energia.requests;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import it.epicode.energia.model.RagioneSociale;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModificaClienteRequest {

	private String partitaIva;
	@Enumerated(EnumType.STRING)
	private RagioneSociale ragioneSociale;
	private String dataInserimento;
	private String dataUltimoContatto;
	private Double fatturatoAnnuale;
	private String pec;
	private String telefono;
	private String emailContatto;
	private String nomeContatto;
	private String cognomeContatto;
	private String telefonoContatto;
	private int id_iso;
	private int id_isl;
	private int numero;
}
