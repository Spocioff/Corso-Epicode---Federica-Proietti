package it.epicode.energia.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.model.Comune;
import it.epicode.energia.model.Fattura;
import it.epicode.energia.model.IndirizzoSedeLegale;
import it.epicode.energia.model.IndirizzoSedeOperativa;
import it.epicode.energia.model.Provincia;
import it.epicode.energia.repository.ComuneRepository;
import it.epicode.energia.repository.IndirizzoSedeLegaleRepository;
import it.epicode.energia.repository.IndirizzoSedeOperativaRepository;
import it.epicode.energia.repository.ProvinciaRepository;
import it.epicode.energia.requests.InserisciComuneRequest;
import it.epicode.energia.requests.ModificaComuneRequest;

@Service
public class ComuneService {
@Autowired
ComuneRepository cr;
@Autowired
IndirizzoSedeOperativaRepository isorep;
@Autowired
IndirizzoSedeLegaleRepository islrep;
@Autowired
ProvinciaRepository pr;

public boolean inserisciComune(InserisciComuneRequest request) {


Comune c = new Comune();

BeanUtils.copyProperties(request, c);
cr.save(c);
return true;
}

public boolean eliminaComune ( int id) {
if(!cr.existsById(id)) {
	return false;
}
cr.deleteById(id);
return true;
}
public boolean modificaComune (ModificaComuneRequest request, int id) {
if(!cr.existsById(request.getId()) && !pr.existsById(request.getSigla())&& !islrep.existsById(request.getId_isl()) && !isorep.existsById(request.getId_iso())) {
	return false;
}
Comune c = cr.findById(id).get();
Provincia p = pr.findById(request.getSigla()).get();
IndirizzoSedeLegale isl = islrep.findById(request.getId_isl()).get();
IndirizzoSedeOperativa iso = isorep.findById(request.getId_iso()).get();
c.setProvincia(p);
c.getIndirizziSL().add(isl);
c.getIndirizziSO().add(iso);
BeanUtils.copyProperties(request, c);
c.setId(id);
cr.save(c);
return true;
} 
public List<Comune> getAllComuni() {
return (List<Comune>) cr.findAll();
}
public Comune findComuneById (int id) {
if(!cr.existsById(id)) {
	return null;
}
return cr.findById(id).get();
}

public Page tuttiComuniPaginati(Pageable page) {
	return cr.findAll(page);
}

}