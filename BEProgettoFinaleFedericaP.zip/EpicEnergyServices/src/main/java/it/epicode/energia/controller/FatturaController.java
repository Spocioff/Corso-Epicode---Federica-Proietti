package it.epicode.energia.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.errors.NotFoundException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Fattura;
import it.epicode.energia.requests.InserisciClienteRequest;
import it.epicode.energia.requests.InserisciFatturaRequest;
import it.epicode.energia.requests.ModificaClienteRequest;
import it.epicode.energia.requests.ModificaFatturaRequest;
import it.epicode.energia.requests.getAnnoBetweenRequest;
import it.epicode.energia.requests.getFatturaByDataBetweenRequest;
import it.epicode.energia.requests.getFatturatoAnnualeBetweenRequest;
import it.epicode.energia.requests.getRangeImportiBetweenRequest;
import it.epicode.energia.services.ClienteService;
import it.epicode.energia.services.FatturaService;

/**
 * Servizi rest relativi alla classe Fattura
 * @author Federica Proietti
 */
@RestController
@RequestMapping("/fattura")
@Tag(name= "Fatture")
public class FatturaController {

	@Autowired
	FatturaService fs;
	/**
	 * Inserimento a DB di una fattura
	 * associato ad il metodo Post
	 * @throws GiaEsistenteException 
	 */
	@Operation (summary = "Inserisce un Fattura nel DB", description = "Inserisce una Fattura nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Fattura inserita con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE, path = "/inserisci-fattura")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity inserisciFattura(@Valid @RequestBody InserisciFatturaRequest request) throws GiaEsistenteException{
		if(fs.inserisciFattura(request)) {
			return ResponseEntity.ok("FATTURA INSERITA");}
		else {return new ResponseEntity("INSERIMENTO FALLITO", HttpStatus.FAILED_DEPENDENCY);
		}
	}	
	/**
	 * Elimina una fattura a DB con id associato a quello passato in input
	 * associato al metodo DELETE
	 * @param numero
	 * @return
	 */
	@Operation (summary = "Cancella una Fattura", description = "Cancella una Fattura immettendo il suo id")
	@ApiResponse(responseCode = "200", description = "Fattura cancellata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@DeleteMapping("/{numero}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity eliminaFattura(@PathVariable ("numero") Integer numero) {
		boolean trovato = fs.eliminaFattura(numero);
		if(trovato) {
			return ResponseEntity.ok("FATTURA ELIMINATA");}
		return new ResponseEntity("FATTURA NON TROVATA", HttpStatus.NOT_FOUND);
	}
	/**
	 * Effettua un update della fattura corrispondente all'id dato in input
	 *  associato al metodo PUT
	 * @param request
	 * @param numero
	 * @return
	 * @throws NotFoundException
	 */
	@Operation (summary = "Modifica una Fattura", description = "Modifica i dati di una Fattura")
	@ApiResponse(responseCode = "200", description = "Fattura modificata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PutMapping("/modifica-fattura/{numero}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity modificaFattura (@Valid @RequestBody ModificaFatturaRequest request, @PathVariable Integer numero) throws NotFoundException {
		 fs.modificaFattura(numero, request);
		 return ResponseEntity.ok("FATTURA MODIFICATA");
	}
	/**
	 * Recupera tutti le Fatture a DB
	 * associato al metodo GET
	 * @return
	 */
	@Operation (summary = "Mostra tutte le Fatture", description = "Mostra tutte le Fatture presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutte le Fatture visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllFatture() {
		return ResponseEntity.ok(fs.getAllFatture());
	}
	/**
	 * Recupera tutte le Fatture a DB
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutte le Fatture paginate", description = "Mostra tutte le Fatture presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutte le Fatture visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/get-all-fatture-paginate")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity tutteFatturePaginate(Pageable page) {
		return ResponseEntity.ok(fs.tutteFatturePaginate(page));
	}
	/**
	 * Recupera le Fatture a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param numero
	 * @return
	 */
	@Operation (summary = "Cerca le Fatture in base all'id", description = "Cerca le Fatture nel DB in base all'id")
	@ApiResponse(responseCode = "200", description = "Lista Fatture visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/{numero}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getFattureById(@PathVariable Integer numero) {
		Fattura f = fs.findFatturaById(numero);
		if(f== null) {
			return new ResponseEntity("FATTURA NON TROVATA", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(f);
	}
	@Operation (summary = "Mostra le fatture dal DB filtrate per anno", description = "Mostra tutti le fatture presenti nel DB filtrate anno")
	@ApiResponse(responseCode = "200", description = "Lista di tutte le fatture visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping("/fattura-by-anno")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity getAnnoFattura(@RequestBody getAnnoBetweenRequest request, Pageable page) throws NotFoundException {
		List<Fattura> f = fs.getAnnoFatturaBetween(request, page);
		if(f==null) {
		return new ResponseEntity ("FATTURA NON TROVATA", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(f);
	}
	@Operation (summary = "Mostra le fatture dal DB filtrati per range importi", description = "Mostra tutti le fatture presenti nel DB filtrati per range importi")
	@ApiResponse(responseCode = "200", description = "Lista di tutte le fatture visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping("/fattura-range-importi")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity getRangeImportiFatture(@RequestBody getRangeImportiBetweenRequest request, Pageable page) throws NotFoundException {
		List<Fattura> f = fs.getRangeImporti(request, page);
		if(f==null) {
		return new ResponseEntity ("FATTURA NON TROVATA", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(f);
	}
	@Operation (summary = "Mostra le fatture dal DB filtrate per data", description = "Mostra tutti le fatture presenti nel DB filtrate per data")
	@ApiResponse(responseCode = "200", description = "Lista di tutte le fatture visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping("/fattura-by-data")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity getFattureByData(@RequestBody getFatturaByDataBetweenRequest request, Pageable page) throws NotFoundException {
		List<Fattura> f = fs.getByData(request, page);
		if(f==null) {
		return new ResponseEntity ("FATTURA NON TROVATA", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(f);
	}
}