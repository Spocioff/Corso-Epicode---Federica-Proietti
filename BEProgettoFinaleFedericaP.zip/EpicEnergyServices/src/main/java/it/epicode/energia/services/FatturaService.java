package it.epicode.energia.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.errors.NotFoundException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Fattura;
import it.epicode.energia.repository.ClienteRepository;
import it.epicode.energia.repository.FatturaRepository;
import it.epicode.energia.requests.InserisciFatturaRequest;
import it.epicode.energia.requests.ModificaFatturaRequest;
import it.epicode.energia.requests.getAnnoBetweenRequest;
import it.epicode.energia.requests.getFatturaByDataBetweenRequest;
import it.epicode.energia.requests.getFatturatoAnnualeBetweenRequest;
import it.epicode.energia.requests.getRangeImportiBetweenRequest;

@Service
public class FatturaService {
	@Autowired
	FatturaRepository fr;
	@Autowired
	ClienteRepository cr;

	public boolean inserisciFattura(InserisciFatturaRequest request) throws GiaEsistenteException {
		if(fr.existsById(request.getNumero())) {
			throw new GiaEsistenteException("Attenzione, la fattura è già stata inserita");
		}
		Fattura f = new Fattura();
		f.getCliente();
		BeanUtils.copyProperties(request, f);
		fr.save(f);
		return true;
	}
	public boolean eliminaFattura(Integer numero) {
		if(!fr.existsById(numero)) {
			return false;
		}
		fr.deleteById(numero);
		return true;
	}
	public void modificaFattura(Integer numero, ModificaFatturaRequest request) throws NotFoundException {
		if(fr.existsById(numero) && cr.existsById(request.getPartitaIva())) {
			Fattura f = fr.findById(numero).get();
			BeanUtils.copyProperties(request, f);
			f.setNumero(numero);
			fr.save(f);
		}else { throw new NotFoundException("Fattura non trovata");

		}
	}
	public List<Fattura> getAllFatture(){
		return (List<Fattura>) fr.findAll();
	}
	public Page tutteFatturePaginate(Pageable page) {
		return fr.findAll(page);
	}
	public Fattura findFatturaById (Integer numero) {
		if(!fr.existsById(numero)) {
			return null;
		}
		return fr.findById(numero).get();
	}
	public List<Fattura> getAnnoFatturaBetween (getAnnoBetweenRequest request, Pageable page) throws NotFoundException{
		
		return  fr.findByAnnoBetween(request.getAnnoDa(), request.getAnnoA(), page);
	}
	public List<Fattura> getRangeImporti (getRangeImportiBetweenRequest request, Pageable page) throws NotFoundException{
		
		return  fr.findByImportoBetween(request.getImportoDa(), request.getImportoA(), page);
	}
public List<Fattura> getByData (getFatturaByDataBetweenRequest request, Pageable page) throws NotFoundException{
		
		return  fr.findByDataBetween(request.getDataoDa(), request.getDataA(), page);
}

}
