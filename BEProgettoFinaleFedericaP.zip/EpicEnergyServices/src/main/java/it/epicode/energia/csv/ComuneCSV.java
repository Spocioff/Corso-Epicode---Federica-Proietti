 package it.epicode.energia.csv;

import com.fasterxml.jackson.annotation.JsonProperty;

import it.epicode.energia.model.Provincia;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ComuneCSV {
	@JsonProperty("CAP")
	private String cap;
	@JsonProperty("Comune")
	private String nome;
	@JsonProperty("Provincia")
	private String provincia;
}
