package it.epicode.energia.repository;


import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;


import it.epicode.energia.model.Fattura;
import it.epicode.energia.model.StatoFattura;

public interface FatturaRepository extends PagingAndSortingRepository<Fattura, Integer> {
	 List<Fattura> findByDataBetween(String dataDa,String dataA, Pageable page);
	 List<Fattura> findByAnnoBetween(int annoDa, int annoA, Pageable page);
	 List<Fattura> findByImportoBetween(Double importoDa, Double importoA,  Pageable page);
	 List<Fattura> findByClienteContaining (String cliente, Pageable page);
	 List<Fattura> findByStatoContaining (StatoFattura stato, Pageable page);
}
