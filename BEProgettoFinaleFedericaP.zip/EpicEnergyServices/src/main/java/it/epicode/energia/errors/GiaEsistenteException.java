package it.epicode.energia.errors;

public class GiaEsistenteException extends Exception{

	public GiaEsistenteException(String message) {
		super(message);
		
	}
	
	

}
