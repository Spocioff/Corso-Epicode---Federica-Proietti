package it.epicode.energia.requests;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class getDataUltimoContattoBetweenRequest {

	private String dataUltimoContattoDa;
	private String dataUltimoContattoA;
}
