package it.epicode.energia.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.errors.NotFoundException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Fattura;
import it.epicode.energia.model.Provincia;
import it.epicode.energia.requests.InserisciClienteRequest;
import it.epicode.energia.requests.InserisciFatturaRequest;
import it.epicode.energia.requests.InserisciProvinciaRequest;
import it.epicode.energia.requests.ModificaClienteRequest;
import it.epicode.energia.requests.ModificaFatturaRequest;
import it.epicode.energia.requests.ModificaProvinciaRequest;
import it.epicode.energia.services.ClienteService;
import it.epicode.energia.services.FatturaService;
import it.epicode.energia.services.ProvinciaService;

/**
 * Servizi rest relativi alla classe Provincia
 * @author Federica Proietti
 */
@RestController
@RequestMapping("/provincia")
@Tag(name= "Province")
public class ProvinciaController {

	@Autowired
	ProvinciaService ps;
	/**
	 * Inserimento a DB di una fattura
	 * associato ad il metodo Post
	 * @throws GiaEsistenteException 
	 */
	@Operation (summary = "Inserisce una Provincia nel DB", description = "Inserisce una Provincia nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Provincia inserita con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE, path = "/inserisci-provincia")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity inserisciProvincia(@Valid @RequestBody InserisciProvinciaRequest request) {
		if(ps.inserisciProvincia(request)) {
			return ResponseEntity.ok("PROVINCIA INSERITA");}
		else {return new ResponseEntity("INSERIMENTO FALLITO", HttpStatus.FAILED_DEPENDENCY);
		}
	}	
	/**
	 * Elimina una Provincia a DB con id associato a quello passato in input
	 * associato al metodo DELETE
	 * @param sigla
	 * @return
	 */
	@Operation (summary = "Cancella una Provincia", description = "Cancella una Provincia immettendo il suo id")
	@ApiResponse(responseCode = "200", description = "Provincia cancellata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@DeleteMapping("/{sigla}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity eliminaProvincia(@PathVariable ("sigla") String sigla) {
		boolean trovato = ps.eliminaProvincia(sigla);
		if(trovato) {
			return ResponseEntity.ok("PROVINCIA ELIMINATA");}
		return new ResponseEntity("PROVINCIA NON TROVATA", HttpStatus.NOT_FOUND);
	}
	/**
	 * Effettua un update della Provincia corrispondente all'id dato in input
	 *  associato al metodo PUT
	 * @param request
	 * @param sigla
	 * @return
	 * @throws NotFoundException
	 */
	@Operation (summary = "Modifica una Provincia", description = "Modifica i dati di una Provincia")
	@ApiResponse(responseCode = "200", description = "Provincia modificata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PutMapping("/modifica-provincia/{sigla}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity modificaFattura (@Valid @RequestBody ModificaProvinciaRequest request, @PathVariable String sigla) throws NotFoundException {
		 ps.modificaProvincia(request, sigla);
		 return ResponseEntity.ok("PROVINCIA MODIFICATA");
	}
	/**
	 * Recupera tutte le Province a DB
	 * associato al metodo GET
	 * @return
	 */
	@Operation (summary = "Mostra tutte le Province", description = "Mostra tutte le Province presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutte le Province visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllProvince() {
		return ResponseEntity.ok(ps.getAllProvince());
	}
	/**
	 * Recupera tutte le Province a DB
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutte le Province", description = "Mostra tutte le Province presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutte le Province visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("get-all-province-paginate")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity tutteFatturePaginate(Pageable page) {
		return ResponseEntity.ok(ps.tutteProvincePaginate(page));
	}
	/**
	 * Recupera le Province a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param sigla
	 * @return
	 */
	@Operation (summary = "Cerca le Province in base all'id", description = "Cerca le Province nel DB in base all'id")
	@ApiResponse(responseCode = "200", description = "Lista Province visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/{sigla}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity findProvinceById(@PathVariable String sigla) {
		Provincia p = ps.findProvinceBySigla(sigla);
		if(p== null) {
			return new ResponseEntity("PROVINCIA NON TROVATA", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(p);
	}
	
}