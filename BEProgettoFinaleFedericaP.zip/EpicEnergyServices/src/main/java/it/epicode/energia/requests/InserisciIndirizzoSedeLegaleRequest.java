package it.epicode.energia.requests;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
public class InserisciIndirizzoSedeLegaleRequest {

//	private int id;
	private String via;
	private int civico;
	private String localita;
	private String cap;
	private String partitaIva;
	private int id_comune;
}
