package it.epicode.energia.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.energia.model.IndirizzoSedeLegale;

public interface IndirizzoSedeLegaleRepository extends PagingAndSortingRepository<IndirizzoSedeLegale, Integer> {

}
