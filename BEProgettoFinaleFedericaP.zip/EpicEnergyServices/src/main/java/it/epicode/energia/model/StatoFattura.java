package it.epicode.energia.model;

public enum StatoFattura {
	IN_LAVORAZIONE,
	SALDATO,
	NON_SALDATO;
	
}
