package it.epicode.energia.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Comune;
import it.epicode.energia.model.IndirizzoSedeLegale;
import it.epicode.energia.repository.ClienteRepository;
import it.epicode.energia.repository.ComuneRepository;
import it.epicode.energia.repository.IndirizzoSedeLegaleRepository;
import it.epicode.energia.requests.InserisciIndirizzoSedeLegaleRequest;
import it.epicode.energia.requests.ModificaIndirizzoSedeLegaleRequest;

@Service
public class IndirizzoSedeLegaleService {
	@Autowired
	ClienteRepository cr;
	@Autowired
	ComuneRepository cor;
	@Autowired
	IndirizzoSedeLegaleRepository islr;
	
	public boolean inserisciIndirizzoSedeLegale(InserisciIndirizzoSedeLegaleRequest request)  {
		
		IndirizzoSedeLegale isl = new IndirizzoSedeLegale();
	    BeanUtils.copyProperties(request, isl);
		islr.save(isl);
		return true;
	}	
	public boolean eliminaIndirizzoSedeLegale( int id) {
		if(!islr.existsById(id)) {
			return false;
		}
		islr.deleteById(id);
		return true;

}
	public boolean modificaIndirizzoSedeLegale (ModificaIndirizzoSedeLegaleRequest request, int id) {
		if(!islr.existsById(request.getId()) && !cr.existsById(request.getPartitaIva())) {
			return false;
	}
		IndirizzoSedeLegale isl = islr.findById(id).get();
		Cliente c = cr.findById(request.getPartitaIva()).get();
		Comune co = cor.findById(request.getId_comune()).get();
		isl.setCliente(c);
		isl.setComune(co);
	    BeanUtils.copyProperties(request, isl);
	    isl.setId(id);
		islr.save(isl);
		return true;
	}	

	public List<IndirizzoSedeLegale> mostraTuttiIndirizziSediLegali() {
		return (List<IndirizzoSedeLegale>) islr.findAll();
	}
	public Page tuttiIndirizziPaginati(Pageable page) {
		return cr.findAll(page);
	}
	
	public IndirizzoSedeLegale findIndirizzoById (int id) {
		if(!islr.existsById(id)) {
			return null;
		}
		return islr.findById(id).get();
	}
}
