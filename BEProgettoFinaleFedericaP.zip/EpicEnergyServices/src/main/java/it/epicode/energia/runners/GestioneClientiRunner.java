package it.epicode.energia.runners;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;


import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Comune;
import it.epicode.energia.model.Fattura;
import it.epicode.energia.model.IndirizzoSedeLegale;
import it.epicode.energia.model.IndirizzoSedeOperativa;
import it.epicode.energia.model.Provincia;
import it.epicode.energia.model.RagioneSociale;
import it.epicode.energia.model.StatoFattura;
import it.epicode.energia.repository.ClienteRepository;
import it.epicode.energia.repository.ComuneRepository;
import it.epicode.energia.repository.FatturaRepository;
import it.epicode.energia.repository.IndirizzoSedeLegaleRepository;
import it.epicode.energia.repository.IndirizzoSedeOperativaRepository;
import it.epicode.energia.repository.ProvinciaRepository;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Component
public class GestioneClientiRunner implements CommandLineRunner{

	@Autowired
	ClienteRepository clr;
	@Autowired
	ComuneRepository comr;
	@Autowired
	ProvinciaRepository pr;
	@Autowired
	FatturaRepository fr;
	@Autowired
	IndirizzoSedeLegaleRepository islr;
	@Autowired
	IndirizzoSedeOperativaRepository isor;
	
	@Override
	public void run(String... args) throws Exception {
	Cliente c = Cliente.builder().nomeContatto("Mario").cognomeContatto("Bros").dataInserimento("2019-05-22").dataUltimoContatto("2022-04-05")
			.emailContatto("supermario@gmail.com").pec("supermario@pec.it").telefono("3409912453").partitaIva("86334519757")
			.fatturatoAnnuale(800000.00).ragioneSociale(RagioneSociale.PA).telefonoContatto("06898098").build();
	Cliente c2 = Cliente.builder().nomeContatto("Luigi").cognomeContatto("Porello").dataInserimento("2018-04-22").dataUltimoContatto("2021-04-23")
			.emailContatto("luigi@gmail.com").pec("luigi@pec.it").telefono("3402212453").partitaIva("BBB12334519757")
			.fatturatoAnnuale(600000.00).ragioneSociale(RagioneSociale.SAS).telefonoContatto("06123098").build();	
	Cliente c3 = Cliente.builder().nomeContatto("Peach").cognomeContatto("Pesca").dataInserimento("2017-04-22").dataUltimoContatto("2020-10-11")
			.emailContatto("peach@gmail.com").pec("peach@pec.it").telefono("3498882453").partitaIva("45634519757")
			.fatturatoAnnuale(5000000.00).ragioneSociale(RagioneSociale.SPA).telefonoContatto("06456098").build();
	
	Comune com = Comune.builder().cap("67030").nome("ABAZIA DI SULMONA").build();
	Comune com2 = Comune.builder().cap("00100").nome("ROMA").build(); 
	Comune com3 = Comune.builder().cap("41100").nome("MODENA").build(); 
	
	Provincia p = Provincia.builder().sigla("AQ").provincia("L'Aquila").regione("Abruzzo").build();
	Provincia p2 = Provincia.builder().sigla("RM").provincia("ROMA").regione("Lazio").build();
	Provincia p3 = Provincia.builder().sigla("MO").provincia("Modena").regione("Emilia Romagna").build();
	
	IndirizzoSedeOperativa iso = IndirizzoSedeOperativa.builder().cap("67030").localita("ABAZIA DI SULMONA").via("via del pesce").civico(3).build();
	IndirizzoSedeOperativa iso2 = IndirizzoSedeOperativa.builder().cap("00100").localita("ROMA").via("via dei fori imperiali").civico(5).build();
	IndirizzoSedeOperativa iso3 = IndirizzoSedeOperativa.builder().cap("41100").localita("MODENA").via("via dei fiori").civico(75).build();
	
	IndirizzoSedeLegale isl = IndirizzoSedeLegale.builder().cap("67030").localita("ABAZIA DI SULMONA").via("via del mare").civico(33).build();
	IndirizzoSedeLegale isl2 = IndirizzoSedeLegale.builder().cap("00100").localita("ROMA").via("via collatina").civico(1225).build();
	IndirizzoSedeLegale isl3 = IndirizzoSedeLegale.builder().cap("41100").localita("MODENA").via("via dei papaveri").civico(95).build();
	
	Fattura f = Fattura.builder().numero(123).anno(2018).data("2018-03-15").stato(StatoFattura.SALDATO).importo(2000.00).build();
	Fattura f2 = Fattura.builder().numero(345).anno(2019).data("2019-02-15").stato(StatoFattura.IN_LAVORAZIONE).importo(2800.00).build();
	Fattura f3 = Fattura.builder().numero(567).anno(2021).data("2021-05-15").stato(StatoFattura.NON_SALDATO).importo(1500.00).build();
	
	
	clr.save(c);
	clr.save(c2);
	log.info("----------------------contatto 2-----------------" + c2);
	clr.save(c3);
	
	comr.save(com);
	comr.save(com2);
	comr.save(com3);
	
	pr.save(p);
	pr.save(p2);
	pr.save(p3);
	
	islr.save(isl);
	islr.save(isl2);
	islr.save(isl3);
	
	isor.save(iso);
	isor.save(iso2);
	isor.save(iso3);
	
	fr.save(f);
	fr.save(f2);
	fr.save(f3);

	log.info("Cliente: " + c.getNomeContatto()+ " "+ c.getCognomeContatto()+ " "+ c.getDataInserimento());
	}

}
