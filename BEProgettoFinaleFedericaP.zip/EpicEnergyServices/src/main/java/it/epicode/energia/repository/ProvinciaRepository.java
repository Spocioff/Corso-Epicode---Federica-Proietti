package it.epicode.energia.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.energia.model.Provincia;

public interface ProvinciaRepository extends PagingAndSortingRepository<Provincia, String> {

}
