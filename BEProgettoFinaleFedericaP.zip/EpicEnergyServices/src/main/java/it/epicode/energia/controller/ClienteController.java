package it.epicode.energia.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.errors.NotFoundException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.requests.InserisciClienteRequest;
import it.epicode.energia.requests.ModificaClienteRequest;
import it.epicode.energia.requests.getDataInserimentoBetweenRequest;
import it.epicode.energia.requests.getDataUltimoContattoBetweenRequest;
import it.epicode.energia.requests.getFatturatoAnnualeBetweenRequest;
import it.epicode.energia.services.ClienteService;

/**
 * Servizi rest relativi alla classe Cliente
 * @author Federica Proietti
 */
@RestController
@RequestMapping("/cliente")
@Tag(name= "Clienti")
public class ClienteController {

	@Autowired
	ClienteService cs;
	/**
	 * Inserimento a DB di un cliente
	 * associato ad il metodo Post
	 * @throws GiaEsistenteException 
	 */
	@Operation (summary = "Inserisce un Cliente nel DB", description = "Inserisce un Cliente nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Cliente inserito con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE, path = "/inserisci-cliente")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity inserisciCliente(@Valid @RequestBody InserisciClienteRequest request) throws GiaEsistenteException{
		if(cs.inserisciCliente(request)) {
			return ResponseEntity.ok("CLIENTE INSERITO");}
		else {return new ResponseEntity("INSERIMENTO FALLITO", HttpStatus.FAILED_DEPENDENCY);
		}
	}	
	/**
	 * Elimina un cliente a DB con id associato a quello passato in input
	 * associato al metodo DELETE
	 * @param partitaIva
	 * @return
	 */
	@Operation (summary = "Cancella un Cliente", description = "Cancella un Cliente immettendo il suo id")
	@ApiResponse(responseCode = "200", description = "Cliente cancellato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@DeleteMapping("/{partitaIva}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity eliminaCliente(@PathVariable ("partitaIva") String partitaIva) {
		boolean trovato = cs.eliminaCliente(partitaIva);
		if(trovato) {
			return ResponseEntity.ok("CLIENTE ELIMINATO");}
		return new ResponseEntity("CLIENTE NON TROVATO", HttpStatus.NOT_FOUND);
	}
	/**
	 * Effettua un update del cliente corrispondente all'id dato in input
	 *  associato al metodo PUT
	 * @param request
	 * @param partitaIva
	 * @return
	 * @throws NotFoundException
	 */
	@Operation (summary = "Modifica un Cliente", description = "Modifica i dati di un Cliente")
	@ApiResponse(responseCode = "200", description = "Cliente modificato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PutMapping("/modifica/{partitaIva}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity modificaCliente (@PathVariable ("partitaIva")String partitaIva, @RequestBody ModificaClienteRequest request ) throws NotFoundException {
		boolean trovato = cs.modificaCliente(request, partitaIva);
		if(trovato) {
		cs.modificaCliente(request, partitaIva);
		 return ResponseEntity.ok("CLIENTE MODIFICATO");}
		return new ResponseEntity("CLIENTE NON TROVATO", HttpStatus.NOT_FOUND);
	}
	/**
	 * Recupera tutti i Clienti a DB
	 * associato al metodo GET
	 * @return
	 */
	@Operation (summary = "Mostra tutti i Clienti", description = "Mostra tutti i Clienti presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllClienti() {
		return ResponseEntity.ok(cs.getAllClienti());
	}
	/**
	 * Recupera tutti i Clienti a DB
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutti i Clienti", description = "Mostra tutti i Clienti presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/get-all-clienti-paginati")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity tuttiClientiPaginati(Pageable page) {
		return ResponseEntity.ok(cs.tuttiClientiPaginati(page));
	}
	/**
	 * Recupera i Clienti a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param partitaIva
	 * @return
	 */
	@Operation (summary = "Cerca i Clienti in base all'id", description = "Cerca i Clienti nel DB in base all'id")
	@ApiResponse(responseCode = "200", description = "Lista Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/{partitaIva}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity findClienteById(@PathVariable String partitaIva) {
		Cliente c = cs.findClienteById(partitaIva);
		if(c== null) {
			return new ResponseEntity("CLIENTE NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
	}
	/**
	 * Recupera i Clienti a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutti i Clienti ordinati per nome", description = "Mostra tutti i Clienti presenti nel DB ordinandoli per nome secondo ordine decrescente")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/get-by-nome-contatto")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllClientiOrderByNomeContattoDesc(Pageable page) {
		return ResponseEntity.ok(cs.getAllClientiOrderByNomeContattoDesc());
}
	/**
	 * Recupera i Clienti a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutti i Clienti ordinati per fatturato annuale", description = "Mostra tutti i Clienti presenti nel DB ordinandoli per fatturato annuale secondo ordine decrescente")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/get-by-fatturato-annuale")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllClientiOrderByFatturatoAnnualeDesc(Pageable page) {
		return ResponseEntity.ok(cs.getAllClientiOrderByFatturatoAnnualeDesc());
	}
	/**
	 * Recupera i Clienti a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutti i Clienti secondo ordine decrescente data inserimento", description = "Mostra tutti i Clienti presenti nel DB ordinandoli per data inserimento secondo ordine decrescente")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/get-by-data-inserimento")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllClientiOrderByDataInserimentoDesc(Pageable page) {
		return ResponseEntity.ok(cs.getAllClientiOrderByDataInsermentoDesc());
	}
	/**
	 * Recupera i Clienti a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutti i Clienti secondo ordine decrescente data utimo contatto", description = "Mostra tutti i Clienti presenti nel DB ordinandoli per data utimo contatto secondo ordine decrescente")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/get-by-data-utimo-contatto")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllClientiOrderByDataUltimoContattoDesc(Pageable page) {
		return ResponseEntity.ok(cs.getAllClientiOrderByDataUltimoContattoDesc());
	}
	@Operation (summary = "Mostra tutti i Clienti dal DB filtrati per nome", description = "Mostra tutti i Clienti presenti nel DB che contengono la lettera passata in input")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/nome-containing/{nomeContatto}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getClientiByNomeContattoContaining(@PathVariable("nomeContatto") String nomeContatto, Pageable page) throws NotFoundException {
		List<Cliente> c = cs.getNomeContattoContaining(nomeContatto, page);
		if(c==null) {
		return new ResponseEntity ("CLIENTE NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
}
	@Operation (summary = "Mostra i Clienti dal DB filtrati per data ultimo contratto", description = "Mostra tutti i Clienti presenti nel DB filtrati per data ultimo contratto")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping("/data-ultimo-contatto-between")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity getDataUltimoContatto(@RequestBody getDataUltimoContattoBetweenRequest request, Pageable page) throws NotFoundException {
		List<Cliente> c = cs.getDataUltimoContattoBetween(request, page);
		if(c==null) {
		return new ResponseEntity ("CLIENTE NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
}
	@Operation (summary = "Mostra i Clienti dal DB filtrati per fatturato annuale", description = "Mostra tutti i Clienti presenti nel DB filtrati  per fatturato annuale")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping("/fatturato-annuale")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity getFatturatoAnnuale(@RequestBody getFatturatoAnnualeBetweenRequest request, Pageable page) throws NotFoundException {
		List<Cliente> c = cs.getFatturatoAnnualeBetween(request, page);
		if(c==null) {
		return new ResponseEntity ("CLIENTE NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
	}
	@Operation (summary = "Mostra i Clienti dal DB filtrati per data inserimento", description = "Mostra tutti i Clienti presenti nel DB filtrati per data inserimento")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Clienti visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping("/data-inserimento")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity getDataInserimento(@RequestBody getDataInserimentoBetweenRequest request, Pageable page) throws NotFoundException {
		List<Cliente> c =  cs.getDataInserimentoBetween(request, page);
		if(c==null) {
		return new ResponseEntity ("CLIENTE NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
	}
}