package it.epicode.energia.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.errors.NotFoundException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Comune;
import it.epicode.energia.model.Fattura;
import it.epicode.energia.model.IndirizzoSedeLegale;
import it.epicode.energia.model.IndirizzoSedeOperativa;
import it.epicode.energia.requests.InserisciClienteRequest;
import it.epicode.energia.requests.InserisciComuneRequest;
import it.epicode.energia.requests.InserisciFatturaRequest;
import it.epicode.energia.requests.InserisciIndirizzoSedeLegaleRequest;
import it.epicode.energia.requests.InserisciIndirizzoSedeOperativaRequest;
import it.epicode.energia.requests.ModificaClienteRequest;
import it.epicode.energia.requests.ModificaComuneRequest;
import it.epicode.energia.requests.ModificaFatturaRequest;
import it.epicode.energia.requests.ModificaIndirizzoSedeLegaleRequest;
import it.epicode.energia.requests.ModificaIndirizzoSedeOperativaRequest;
import it.epicode.energia.services.ClienteService;
import it.epicode.energia.services.ComuneService;
import it.epicode.energia.services.FatturaService;
import it.epicode.energia.services.IndirizzoSedeLegaleService;
import it.epicode.energia.services.IndirizzoSedeOperativaService;

/**
 * Servizi rest relativi alla classe IndirizzoSedeOperativa
 * @author Federica Proietti
 */
@RestController
@RequestMapping("/indirizzoSedeOperativa")
@Tag(name= "IndirizziSedeOperativa")
public class IndirizzoSedeOperativaController {

	@Autowired
	IndirizzoSedeOperativaService isos;
	/**
	 * Inserimento a DB di un comune
	 * associato ad il metodo Post
	 * @throws GiaEsistenteException 
	 */
	@Operation (summary = "Inserisce un Indirizzo nel DB", description = "Inserisce un Indirizzo nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Indirizzo inserito con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE, path = "/inserisci-indirizzo")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity inserisciIndirizzo(@Valid @RequestBody InserisciIndirizzoSedeOperativaRequest request) {
		if(isos.inserisciIndirizzoSedeOperativa(request)) {
			return ResponseEntity.ok("INDIRIZZO INSERITO");}
		else {return new ResponseEntity("INSERIMENTO FALLITO", HttpStatus.FAILED_DEPENDENCY);
		}
	}	
	/**
	 * Elimina un Indirizzo a DB con id associato a quello passato in input
	 * associato al metodo DELETE
	 * @param id
	 * @return
	 */
	@Operation (summary = "Cancella un Indirizzo", description = "Cancella un Indirizzo immettendo il suo id")
	@ApiResponse(responseCode = "200", description = "Indirizzo cancellato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@DeleteMapping("/{id}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity eliminaIndirizzo(@PathVariable ("id") int id) {
		boolean trovato = isos.eliminaIndirizzoSedeOperativa(id);
		if(trovato) {
			return ResponseEntity.ok("INDIRIZZO ELIMINATO");}
		return new ResponseEntity("INDIRIZZO NON TROVATO", HttpStatus.NOT_FOUND);
	}
	/**
	 * Effettua un update del Indirizzo corrispondente all'id dato in input
	 *  associato al metodo PUT
	 * @param request
	 * @param id
	 * @return
	 * @throws NotFoundException
	 */
	@Operation (summary = "Modifica un Indirizzo", description = "Modifica i dati di un Indirizzo")
	@ApiResponse(responseCode = "200", description = "Indirizzo modificato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PutMapping("/modifica-indirizzo/{id}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity modificaIndirizzo (@Valid @RequestBody ModificaIndirizzoSedeOperativaRequest request, @PathVariable int id) throws NotFoundException {
		 isos.modificaIndirizzoSedeOperativa(request, id);
		 return ResponseEntity.ok("INDIRIZZO MODIFICATO");
	}
	/**
	 * Recupera tutti gli Indirizzi a DB
	 * associato al metodo GET
	 * @return
	 */
	@Operation (summary = "Mostra tutti gli Indirizzi", description = "Mostra tutti gli Indirizzi presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti gli Indirizzi visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllIndirizzi() {
		return ResponseEntity.ok(isos.getAllIndirizziSediOperativa());
	}
	/**
	 * Recupera tutti gli Indirizzi a DB
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutti gli Indirizzi", description = "Mostri gli Indirizzi presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti gli Indirizzi visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("get-all-indirizzi-paginati")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity tuttiIndirizziPaginati(Pageable page) {
		return ResponseEntity.ok(isos.tuttiIndirizziPaginati(page));
	}
	/**
	 * Recupera gli Indirizzi a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param id
	 * @return
	 */
	@Operation (summary = "Cerca gli Indirizzi in base all'id", description = "Cerca gli Indirizzi nel DB in base all'id")
	@ApiResponse(responseCode = "200", description = "Lista Indirizzi visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/{id}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity findIndirizzoById(@PathVariable int id) {
		IndirizzoSedeOperativa iso = isos.findIndirizzoById(id);
		if(iso== null) {
			return new ResponseEntity("INDIRIZZO NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(iso);
	}
	
}