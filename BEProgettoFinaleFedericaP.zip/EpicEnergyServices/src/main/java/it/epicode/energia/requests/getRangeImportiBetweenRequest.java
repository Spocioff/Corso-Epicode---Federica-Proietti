package it.epicode.energia.requests;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class getRangeImportiBetweenRequest {

	private Double importoDa;
	private Double importoA;
	
}
