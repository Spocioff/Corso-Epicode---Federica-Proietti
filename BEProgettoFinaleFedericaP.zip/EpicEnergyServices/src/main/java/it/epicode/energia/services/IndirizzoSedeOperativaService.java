package it.epicode.energia.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Comune;
import it.epicode.energia.model.IndirizzoSedeOperativa;
import it.epicode.energia.model.IndirizzoSedeOperativa;
import it.epicode.energia.repository.ClienteRepository;
import it.epicode.energia.repository.ComuneRepository;
import it.epicode.energia.repository.IndirizzoSedeLegaleRepository;
import it.epicode.energia.repository.IndirizzoSedeOperativaRepository;
import it.epicode.energia.requests.InserisciIndirizzoSedeLegaleRequest;
import it.epicode.energia.requests.InserisciIndirizzoSedeOperativaRequest;
import it.epicode.energia.requests.ModificaIndirizzoSedeLegaleRequest;
import it.epicode.energia.requests.ModificaIndirizzoSedeOperativaRequest;

@Service
public class IndirizzoSedeOperativaService {
	@Autowired
	ClienteRepository cr;
	@Autowired
	ComuneRepository cor;
	@Autowired
	IndirizzoSedeOperativaRepository isor;
	
	public boolean inserisciIndirizzoSedeOperativa(InserisciIndirizzoSedeOperativaRequest request) {
		
		IndirizzoSedeOperativa iso = new IndirizzoSedeOperativa();
	    BeanUtils.copyProperties(request, iso);
		isor.save(iso);
		return true;
	}	
	public boolean eliminaIndirizzoSedeOperativa( int id) {
		if(!isor.existsById(id)) {
			return false;
		}
		isor.deleteById(id);
		return true;

}
	public boolean modificaIndirizzoSedeOperativa (ModificaIndirizzoSedeOperativaRequest request, int id) {
		if(!isor.existsById(request.getId()) && !cr.existsById(request.getPartitaIva())) {
			return false;
	}
		IndirizzoSedeOperativa iso = isor.findById(id).get();
		Cliente c = cr.findById(request.getPartitaIva()).get();
		Comune co = cor.findById(request.getId_comune()).get();
		iso.setCliente(c);
		iso.setComune(co);
	    BeanUtils.copyProperties(request, iso);
	    iso.setId(id);
		isor.save(iso);
		return true;
	}	

	public List<IndirizzoSedeOperativa> getAllIndirizziSediOperativa() {
		return (List<IndirizzoSedeOperativa>) isor.findAll();
	}
	public Page tuttiIndirizziPaginati(Pageable page) {
		return cr.findAll(page);
	}
	
	public IndirizzoSedeOperativa findIndirizzoById (int id) {
		if(!isor.existsById(id)) {
			return null;
		}
		return isor.findById(id).get();
	}
}
