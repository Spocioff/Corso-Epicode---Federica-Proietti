 package it.epicode.energia.csv;

import com.fasterxml.jackson.annotation.JsonProperty;

import it.epicode.energia.model.Provincia;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProvinciaCSV {
	@JsonProperty("Sigla")
	private String sigla;
	@JsonProperty("Provincia")
	private String provincia;
	@JsonProperty("Regione")
	private String regione;
}
