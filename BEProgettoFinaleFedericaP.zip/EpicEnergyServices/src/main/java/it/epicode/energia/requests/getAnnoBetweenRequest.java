package it.epicode.energia.requests;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class getAnnoBetweenRequest {

	private int annoDa;
	private int annoA;
	
}
