package it.epicode.energia.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import it.epicode.energia.model.IndirizzoSedeOperativa;

public interface IndirizzoSedeOperativaRepository extends PagingAndSortingRepository<IndirizzoSedeOperativa, Integer> {

}
