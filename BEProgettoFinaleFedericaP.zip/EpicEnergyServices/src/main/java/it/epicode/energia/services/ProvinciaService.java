package it.epicode.energia.services;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.model.Comune;
import it.epicode.energia.model.IndirizzoSedeLegale;
import it.epicode.energia.model.IndirizzoSedeOperativa;
import it.epicode.energia.model.Provincia;
import it.epicode.energia.repository.ComuneRepository;
import it.epicode.energia.repository.IndirizzoSedeLegaleRepository;
import it.epicode.energia.repository.IndirizzoSedeOperativaRepository;
import it.epicode.energia.repository.ProvinciaRepository;
import it.epicode.energia.requests.InserisciComuneRequest;
import it.epicode.energia.requests.InserisciProvinciaRequest;
import it.epicode.energia.requests.ModificaComuneRequest;
import it.epicode.energia.requests.ModificaProvinciaRequest;

@Service
public class ProvinciaService {
@Autowired
ComuneRepository cr;
@Autowired
ProvinciaRepository pr;

public boolean inserisciProvincia(InserisciProvinciaRequest request)  {

Provincia p = new Provincia();
BeanUtils.copyProperties(request, p);
pr.save(p);
return true;
}

public boolean eliminaProvincia ( String sigla) {
if(!pr.existsById(sigla)) {
	return false;
}
pr.deleteById(sigla);
return true;
}
public boolean modificaProvincia (ModificaProvinciaRequest request, String sigla) {
if(!cr.existsById(request.getId()) && !pr.existsById(request.getSigla())) {
	return false;
}
Provincia p = pr.findById(sigla).get();
Comune c = cr.findById(request.getId()).get();
p.getComuni().add(c);
BeanUtils.copyProperties(request, c);
p.setSigla(sigla);
pr.save(p);
return true;
} 
public List<Provincia> getAllProvince() {
return (List<Provincia>) pr.findAll();
}
public Page tutteProvincePaginate(Pageable page) {
	return pr.findAll(page);
}

public Provincia findProvinceBySigla (String sigla) {
if(!pr.existsById(sigla)) {
	return null;
}
return pr.findById(sigla).get();
}
}