package it.epicode.energia.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import net.bytebuddy.dynamic.loading.ClassReloadingStrategy.Strategy;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Comune {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String cap;
	private String nome;
	@ManyToOne
	@ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonIgnore
	private Provincia provincia;
	@OneToMany(mappedBy = "comune",cascade = CascadeType.ALL)
	@ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonIgnore
	private List<IndirizzoSedeOperativa> indirizziSO = new ArrayList<IndirizzoSedeOperativa>();
	@OneToMany(mappedBy = "comune",cascade = CascadeType.ALL)
	@ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonIgnore
	private List<IndirizzoSedeLegale> indirizziSL = new ArrayList<IndirizzoSedeLegale>();
	
}
