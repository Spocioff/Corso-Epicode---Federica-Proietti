package it.epicode.energia.requests;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class getDataInserimentoBetweenRequest {

	private String dataInserimentoDa;
	private String dataInserimentoA;
	
}
