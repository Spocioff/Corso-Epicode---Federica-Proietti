package it.epicode.energia.runners;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import it.epicode.energia.impl.ERole;
import it.epicode.energia.impl.Role;
import it.epicode.energia.impl.RoleRepository;
import it.epicode.energia.impl.User;
import it.epicode.energia.impl.UserRepository;



@Component
public class UserCreationRunner implements CommandLineRunner{

	@Autowired
	PasswordEncoder pe;
	
	@Autowired
	RoleRepository rr;
	
	@Autowired
	UserRepository ur;
	
	@Override
	public void run(String... args) throws Exception {
		
		
			Set hash = new HashSet<Role>();
	        Set hash1 = new HashSet<Role>();
	        Set<Role> roles = new HashSet<Role>();
	        
	        Role admin = Role.builder().roleName(ERole.ROLE_ADMIN).build();
	        Role user = Role.builder().roleName(ERole.ROLE_USER).build();
	        
	        hash.add(admin);
	        hash1.add(user);
	        User u = User.builder().username("feciola").password(BCrypt.hashpw("xxxciao", BCrypt.gensalt())).roles(hash).build();
	        User u1 = User.builder().username("babbollu").password(BCrypt.hashpw("xxxstoca", BCrypt.gensalt())).roles(hash1).build();
	        
	        ur.save(u);
	        ur.save(u1);
		
	}

}
