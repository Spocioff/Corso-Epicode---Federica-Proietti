package it.epicode.energia.requests;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
public class ModificaProvinciaRequest {

	private int id;
	private String sigla;
	private String provincia;
	private String regione;
}
