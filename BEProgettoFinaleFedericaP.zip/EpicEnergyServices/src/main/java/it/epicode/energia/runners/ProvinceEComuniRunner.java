package it.epicode.energia.runners;

import java.io.File;
import java.util.List;
import java.util.Optional;

import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import org.springframework.beans.BeanUtils;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import it.epicode.energia.csv.ComuneCSV;
import it.epicode.energia.csv.ProvinciaCSV;
import it.epicode.energia.model.Comune;
import it.epicode.energia.model.Provincia;
import it.epicode.energia.repository.ComuneRepository;
import it.epicode.energia.repository.ProvinciaRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
@Component



public class ProvinceEComuniRunner implements ApplicationRunner{
	ProvinciaRepository pr;
	ComuneRepository cr;
	
	
	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("avvio runner");
	String fileProvince_italianeCSV = "csv/province_italiane.csv";
	
    CsvSchema province_italianeCSVSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader();
    CsvMapper mapper = new CsvMapper(); 
    File fileProvincia = new ClassPathResource(fileProvince_italianeCSV).getFile(); 
    MappingIterator<List<String>> valueReader = mapper
    		.reader(ProvinciaCSV.class)
    		.with(province_italianeCSVSchema)
    		.readValues(fileProvincia);
    for(Object o : valueReader.readAll()) {
    	Provincia prov = new Provincia();
    	ProvinciaCSV pcsv = (ProvinciaCSV)o;
    	BeanUtils.copyProperties(o, prov);
    	if(prov.getSigla()!= null) {
    	pr.save(prov);
    	}
//    	System.out.println(o);
    }
String fileComuni_italianiCSV = "csv/comuni_italiani.csv";
	
    CsvSchema comuni_italianiCSVSchema = CsvSchema.emptySchema().withColumnSeparator(';').withHeader();
    CsvMapper mapper2 = new CsvMapper(); 
    File fileComune = new ClassPathResource(fileComuni_italianiCSV).getFile(); 
    MappingIterator<List<String>> valueReader2 = mapper2
    		.reader(ComuneCSV.class)
    		.with(comuni_italianiCSVSchema)
    		.readValues(fileComune);
    for(Object o : valueReader2.readAll()) {
    	Comune com = new Comune();
    	ComuneCSV ccsv = (ComuneCSV)o;
    	Optional<Provincia> p = pr.findById(ccsv.getProvincia());
    	if(p.isPresent()) {
    		com.setProvincia(p.get());
    	BeanUtils.copyProperties(o, com);}
    	if(com.getCap() != null) {
    		cr.save(com);
    	}
//    	System.out.println(o);
    }
    
	}

}
