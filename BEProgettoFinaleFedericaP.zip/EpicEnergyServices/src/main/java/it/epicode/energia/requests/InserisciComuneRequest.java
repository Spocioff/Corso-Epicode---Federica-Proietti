package it.epicode.energia.requests;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
public class InserisciComuneRequest {

//	private int id;
	private String cap;
	private String nome;
	private int id_iso;
	private int id_isl;
	private String sigla;
	
}
