package it.epicode.energia.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.errors.NotFoundException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Comune;
import it.epicode.energia.model.Fattura;
import it.epicode.energia.requests.InserisciClienteRequest;
import it.epicode.energia.requests.InserisciComuneRequest;
import it.epicode.energia.requests.InserisciFatturaRequest;
import it.epicode.energia.requests.ModificaClienteRequest;
import it.epicode.energia.requests.ModificaComuneRequest;
import it.epicode.energia.requests.ModificaFatturaRequest;
import it.epicode.energia.services.ClienteService;
import it.epicode.energia.services.ComuneService;
import it.epicode.energia.services.FatturaService;

/**
 * Servizi rest relativi alla classe Comune
 * @author Federica Proietti
 */
@RestController
@RequestMapping("/comune")
@Tag(name= "Comuni")
public class ComuneController {

	@Autowired
	ComuneService cs;
	/**
	 * Inserimento a DB di un comune
	 * associato ad il metodo Post
	 * @throws GiaEsistenteException 
	 */
	@Operation (summary = "Inserisce un Comune nel DB", description = "Inserisce un Comune nel DB con i suoi dati")
	@ApiResponse(responseCode = "200", description = "Comune inserito con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PostMapping(produces = MediaType.TEXT_PLAIN_VALUE, path = "/inserisci-comune")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity inserisciComune(@Valid @RequestBody InserisciComuneRequest request) {
		if(cs.inserisciComune(request)) {
			return ResponseEntity.ok("COMUNE INSERITO");}
		else {return new ResponseEntity("INSERIMENTO FALLITO", HttpStatus.FAILED_DEPENDENCY);
		}
	}	
	/**
	 * Elimina una fattura a DB con id associato a quello passato in input
	 * associato al metodo DELETE
	 * @param id
	 * @return
	 */
	@Operation (summary = "Cancella un Comune", description = "Cancella un Comune immettendo il suo id")
	@ApiResponse(responseCode = "200", description = "Comune cancellato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@DeleteMapping("/{id}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity eliminaComune(@PathVariable ("id") int id) {
		boolean trovato = cs.eliminaComune(id);
		if(trovato) {
			return ResponseEntity.ok("COMUNE ELIMINATO");}
		return new ResponseEntity("COMUNE NON TROVATO", HttpStatus.NOT_FOUND);
	}
	/**
	 * Effettua un update del Comune corrispondente all'id dato in input
	 *  associato al metodo PUT
	 * @param request
	 * @param id
	 * @return
	 * @throws NotFoundException
	 */
	@Operation (summary = "Modifica un Comune", description = "Modifica i dati di un Comune")
	@ApiResponse(responseCode = "200", description = "Comune modificato con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@PutMapping("/modifica-comune/{id}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity modificaComune (@Valid @RequestBody ModificaComuneRequest request, @PathVariable int id) throws NotFoundException {
		 cs.modificaComune(request, id);
		 return ResponseEntity.ok("FATTURA MODIFICATA");
	}
	/**
	 * Recupera tutti i Comuni a DB
	 * associato al metodo GET
	 * @return
	 */
	@Operation (summary = "Mostra tutti i Comuni", description = "Mostra tutti i Comuni presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Comuni visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity getAllComuni() {
		return ResponseEntity.ok(cs.getAllComuni());
	}
	/**
	 * Recupera tutti i Comuni a DB
	 * associato al metodo GET
	 * @param page
	 * @return
	 */
	@Operation (summary = "Mostra tutti i Comuni", description = "Mostri i Comuni presenti nel DB")
	@ApiResponse(responseCode = "200", description = "Lista di tutti i Comuni visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/get-all-comuni-paginati")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity tuttiComuniPaginati(Pageable page) {
		return ResponseEntity.ok(cs.tuttiComuniPaginati(page));
	}
	/**
	 * Recupera le Fatture a DB corrispondenti all'id dato in input
	 * associato al metodo GET
	 * @param partitaIva
	 * @return
	 */
	@Operation (summary = "Cerca i Comuni in base all'id", description = "Cerca i Comuni nel DB in base all'id")
	@ApiResponse(responseCode = "200", description = "Lista Comuni visualizzata con successo")
	@ApiResponse(responseCode = "500", description = "Errore nel server")
	@GetMapping("/{id}")
	@SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("isAuthenticated()")
	public ResponseEntity findFattureById(@PathVariable int id) {
		Comune c = cs.findComuneById(id);
		if(c== null) {
			return new ResponseEntity("COMUNE NON TROVATO", HttpStatus.NOT_FOUND);
		}
		return ResponseEntity.ok(c);
	}
	
}