package it.epicode.energia.model;

public enum RagioneSociale {
	PA,
	SAS,
	SPA,
	SRL;
}
