package it.epicode.energia.services;


import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import it.epicode.energia.errors.GiaEsistenteException;
import it.epicode.energia.errors.NotFoundException;
import it.epicode.energia.model.Cliente;
import it.epicode.energia.model.Fattura;
import it.epicode.energia.model.IndirizzoSedeLegale;
import it.epicode.energia.model.IndirizzoSedeOperativa;
import it.epicode.energia.repository.ClienteRepository;
import it.epicode.energia.repository.FatturaRepository;
import it.epicode.energia.repository.IndirizzoSedeLegaleRepository;
import it.epicode.energia.repository.IndirizzoSedeOperativaRepository;
import it.epicode.energia.requests.InserisciClienteRequest;
import it.epicode.energia.requests.ModificaClienteRequest;
import it.epicode.energia.requests.getDataInserimentoBetweenRequest;
import it.epicode.energia.requests.getDataUltimoContattoBetweenRequest;
import it.epicode.energia.requests.getFatturatoAnnualeBetweenRequest;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ClienteService {

	@Autowired
	ClienteRepository cr;
	@Autowired
	IndirizzoSedeOperativaRepository isorep;
	@Autowired
	IndirizzoSedeLegaleRepository islrep;
	@Autowired
	FatturaRepository fr;
	
	public boolean inserisciCliente (InserisciClienteRequest request) throws GiaEsistenteException{
		if(cr.existsById(request.getPartitaIva())) {
			throw new GiaEsistenteException("Attenzione, il cliente è già stato inserito");
		}
		Cliente c = new Cliente();
		BeanUtils.copyProperties(request, c);
		cr.save(c);
	
		return true;
	}
	public boolean eliminaCliente(String partitaIva) {
		if(!cr.existsById(partitaIva)) {
			return false;
		}
		cr.deleteById(partitaIva);;
		return true;
	}
	public boolean modificaCliente(ModificaClienteRequest request, String partitaIva) throws NotFoundException {
		log.info("=================COSE TROVATE========================");

		

//		if(!cr.existsById(partitaIva) && !fr.existsById(request.getNumero()) && !isorep.existsById(request.getId_iso()) && !islrep.existsById(request.getId_isl())){
//			log.info("=================CLIENTE NON TROVATO========================");
//						log.info(cr.findAll().toString());
//			log.info("=================FATTURA NON TROVATO========================");
//						log.info(fr.findAll().toString());
//			log.info("=================INDIRIZZO NON TROVATO========================");
//						log.info(isorep.findAll().toString());
//			log.info("=================INDIRIZZO NON TROVATO========================");
//
//						log.info(islrep.findAll().toString());
		if(!cr.existsById(partitaIva)) {
			log.info("=================CLIENTE NON TROVATO========================");
			
			
					throw new NotFoundException("Cliente non trovato");	
		} 
		if(!fr.existsById(request.getNumero())) {
			log.info("=================FATTURA NON TROVATO========================");
			throw new NotFoundException("Fattura non trovato");	
		}
		if(!isorep.existsById(request.getId_iso())) {
			log.info("=================INDIRIZZO  iso NON TROVATO========================");
			throw new NotFoundException("indiso non trovato");	
		}
		if(!islrep.existsById(request.getId_isl())) {
			log.info("=================INDIRIZZO  isl NON TROVATO========================");
			throw new NotFoundException("Indisl non trovato");	
		}
		
			Cliente c = cr.findById(partitaIva).get();
			Fattura f = fr.findById(request.getNumero()).get();
			IndirizzoSedeLegale isl = islrep.findById(request.getId_isl()).get();
			IndirizzoSedeOperativa iso = isorep.findById(request.getId_iso()).get();
			c.getFatture().add(f);
			c.setIsl(isl);
			c.setIso(iso);
			f.setCliente(c);
			iso.setCliente(c);
			isl.setCliente(c);
			BeanUtils.copyProperties(request, c);
			c.setPartitaIva(partitaIva);
			cr.save(c);
			
		return true;
	}
	public List<Cliente> getAllClienti(){
		return(List<Cliente>) cr.findAll();
	}
	public Page tuttiClientiPaginati(Pageable page) {
		return cr.findAll(page);
	}
	public Cliente findClienteById (String partitaIva) {
		if(!cr.existsById(partitaIva)) {
			return null;
		}
		return cr.findById(partitaIva).get();
	}
	public List<Cliente> getNomeContattoContaining ( String nomeContatto, Pageable page) throws NotFoundException  {
		
		return cr.findByNomeContattoContaining(nomeContatto, page);
	}
	public List<Cliente> getFatturatoAnnualeBetween (getFatturatoAnnualeBetweenRequest request, Pageable page) throws NotFoundException{
			
		return  cr.findByFatturatoAnnualeBetween(request.getFatturatoAnnualeDa(), request.getFatturatoAnnualeA(), page);
	}
	public List<Cliente> getDataInserimentoBetween(getDataInserimentoBetweenRequest request,Pageable page) throws NotFoundException{
			
		return cr.findByDataInserimentoBetween(request.getDataInserimentoDa(), request.getDataInserimentoA(), page);
	}
	public List<Cliente> getDataUltimoContattoBetween (getDataUltimoContattoBetweenRequest request, Pageable page) throws NotFoundException{
			
		return  cr.findByDataUltimoContattoBetween(request.getDataUltimoContattoDa(), request.getDataUltimoContattoA(), page);
	}
	public List<Cliente> getAllClientiOrderByNomeContattoDesc(){
		return(List<Cliente>) cr.findAllByOrderByNomeContattoDesc();
	}
	public List<Cliente> getAllClientiOrderByFatturatoAnnualeDesc(){
		return(List<Cliente>) cr.findAllByOrderByFatturatoAnnualeDesc();
	}
	public List<Cliente> getAllClientiOrderByDataInsermentoDesc(){
		return(List<Cliente>) cr.findAllByOrderByDataInserimentoDesc();
	}
	public List<Cliente> getAllClientiOrderByDataUltimoContattoDesc(){
		return(List<Cliente>) cr.findAllByOrderByDataUltimoContattoDesc();
	}
}
