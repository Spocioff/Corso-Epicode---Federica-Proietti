package it.epicode.energia.model;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Cliente {
	@Id
	private String partitaIva;
	@Enumerated(EnumType.STRING)
	private RagioneSociale ragioneSociale;;
	private String dataInserimento;
	private String dataUltimoContatto;
	private Double fatturatoAnnuale;
	private String pec;
	private String telefono;
	private String emailContatto;
	private String nomeContatto;
	private String cognomeContatto;
	private String telefonoContatto;
	
	@OneToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonIgnore
	private IndirizzoSedeLegale isl;
	
	@OneToOne(cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonIgnore
	private IndirizzoSedeOperativa iso;

	@OneToMany(mappedBy = "cliente", cascade = {CascadeType.MERGE, CascadeType.PERSIST})
	@ToString.Exclude
    @EqualsAndHashCode.Exclude
    @JsonIgnore
	private List<Fattura> fatture = new ArrayList<Fattura>();
}
