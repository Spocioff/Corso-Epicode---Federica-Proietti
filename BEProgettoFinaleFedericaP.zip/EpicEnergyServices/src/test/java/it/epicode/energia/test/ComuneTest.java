package it.epicode.energia.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.energia.impl.LoginRequest;
import it.epicode.energia.repository.ComuneRepository;
import it.epicode.energia.requests.InserisciComuneRequest;

import it.epicode.energia.requests.ModificaComuneRequest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class ComuneTest {
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	@Autowired
	ComuneRepository cr;
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("feciola");
		login.setPassword("xxxciao");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("babbollu");
		login.setPassword("xxxstoca");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	@Test
	void inserisciComune() {
		String url = "http://localhost:" + port + "/comune/inserisci-comune/";
		InserisciComuneRequest request = new InserisciComuneRequest();
		request.setCap("67061");
		request.setNome("CARSOLI");
		request.setSigla("AQ");
		request.setId_isl(1);
		request.setId_iso(1);
		HttpEntity<InserisciComuneRequest> comuneEntity = new HttpEntity<InserisciComuneRequest>(request);
		log.info("--------------------inserisci-comune--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, comuneEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<InserisciComuneRequest> comuneAdmin = new HttpEntity<InserisciComuneRequest>(request, getAdminHeader() );
		log.info("--------------------inserisci-comune--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, comuneAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<InserisciComuneRequest> comuneUser = new HttpEntity<InserisciComuneRequest>(request, getUserHeader() );
		log.info("--------------------inserisci-comune--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, comuneUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void modificaComune() {
		String url = "http://localhost:" + port + "/comune/modifica-comune/1";
		ModificaComuneRequest request = new ModificaComuneRequest();
		request.setCap("91010");
		request.setNome("CASTELLUZZO");
		request.setSigla("TP");
		request.setId_isl(1);
		request.setId_iso(1);
		HttpEntity<ModificaComuneRequest> comuneEntity = new HttpEntity<ModificaComuneRequest>(request);
		log.info("--------------------mod-comune--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.PUT, comuneEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<ModificaComuneRequest> comuneAdmin = new HttpEntity<ModificaComuneRequest>(request, getAdminHeader() );
		log.info("--------------------mod-comune--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.PUT, comuneAdmin, String.class);
				log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response2.toString());
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<ModificaComuneRequest> comuneUser = new HttpEntity<ModificaComuneRequest>(request, getUserHeader() );
		log.info("--------------------mod-comune--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.PUT, comuneUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaComune() {
		String url = "http://localhost:" + port + "/comune/2";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<String> comuneAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, comuneAdmin, String.class);
		log.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" +response2.toString());
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<String> comuneUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, comuneUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetAllComuni() {
		String url = "http://localhost:" + port + "/comune/";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> comuneAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, comuneAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> comuneUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, comuneUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void GetComuneById() {
		String url = "http://localhost:" + port + "/comune/1";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> comuneAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, comuneAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> comuneUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, comuneUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void GetAllComuniPaginati() {
		String url = "http://localhost:" + port + "/comune/get-all-comuni-paginati";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> comuneAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, comuneAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> comuneUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, comuneUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
}
