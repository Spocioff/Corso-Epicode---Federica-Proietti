package it.epicode.energia.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.energia.impl.LoginRequest;

import it.epicode.energia.repository.IndirizzoSedeLegaleRepository;
import it.epicode.energia.repository.IndirizzoSedeOperativaRepository;
import it.epicode.energia.requests.InserisciIndirizzoSedeOperativaRequest;
import it.epicode.energia.requests.ModificaIndirizzoSedeOperativaRequest;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class IndirizzoSedeOperativaLegaleTest {
	
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	@Autowired
	IndirizzoSedeOperativaRepository isor;
	
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("feciola");
		login.setPassword("xxxciao");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("babbollu");
		login.setPassword("xxxstoca");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	@Test
	void inserisciIndirizzo() {
		String url = "http://localhost:" + port + "/indirizzoSedeOperativa/inserisci-indirizzo";
		InserisciIndirizzoSedeOperativaRequest request = new InserisciIndirizzoSedeOperativaRequest();	
		request.setVia("piazza delle vipere");
		request.setCivico(34);
		request.setLocalita("ROMA");
		request.setCap("00100");
		request.setPartitaIva("45634519757");
		request.setId_comune(2);
		HttpEntity<InserisciIndirizzoSedeOperativaRequest> indirizzoEntity = new HttpEntity<InserisciIndirizzoSedeOperativaRequest>(request);
		log.info("--------------------inserisci-cliente--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, indirizzoEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<InserisciIndirizzoSedeOperativaRequest> indirizzoAdmin = new HttpEntity<InserisciIndirizzoSedeOperativaRequest>(request, getAdminHeader() );
		log.info("--------------------inserisci-cliente--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, indirizzoAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<InserisciIndirizzoSedeOperativaRequest> indirizzoUser = new HttpEntity<InserisciIndirizzoSedeOperativaRequest>(request, getUserHeader() );
		log.info("--------------------inserisci-cliente--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, indirizzoUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void modificaIndirizzo() {
		String url = "http://localhost:" + port + "/indirizzoSedeOperativa/modifica-indirizzo/2";
	ModificaIndirizzoSedeOperativaRequest request = new ModificaIndirizzoSedeOperativaRequest();
	request.setVia("piazza delle serpi");
	request.setCivico(43);
	request.setLocalita("CAGLIARI");
	request.setCap("09100");
	request.setPartitaIva("45634519757");
	request.setId_comune(2);
	HttpEntity<ModificaIndirizzoSedeOperativaRequest> indirizzoEntity = new HttpEntity<ModificaIndirizzoSedeOperativaRequest>(request);
	log.info("--------------------mod-indirizzo--------------------------" + url);
	ResponseEntity<String> response = trt.exchange(url, HttpMethod.PUT, indirizzoEntity, String.class);
	assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<ModificaIndirizzoSedeOperativaRequest> indirizzoAdmin = new HttpEntity<ModificaIndirizzoSedeOperativaRequest>(request, getAdminHeader() );
	log.info("--------------------mod-indirizzo--------------------------" + url);
	log.info("======Token Update=====" + getAdminToken());
	ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.PUT, indirizzoAdmin, String.class);
			log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response2.toString());
	assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	HttpEntity<ModificaIndirizzoSedeOperativaRequest> indirizzoUser = new HttpEntity<ModificaIndirizzoSedeOperativaRequest>(request, getUserHeader() );
	log.info("--------------------mod-indirizzo--------------------------" + url);
	log.info("======Token Update=====" + getUserToken());
	ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.PUT, indirizzoUser, String.class);
	assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaIndirizzo() {
		String url = "http://localhost:" + port + "/indirizzoSedeOperativa/3";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response.toString());
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> indirizzoAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, indirizzoAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> indirizzoUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, indirizzoUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetAllIndirizzi() {
		String url = "http://localhost:" + port + "/indirizzoSedeOperativa/";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> indirizzoAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, indirizzoAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> indirizzoUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, indirizzoUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void findIndirizzoById () {
		String url = "http://localhost:" + port + "/indirizzoSedeOperativa/2";	
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> indirizzoAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, indirizzoAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> indirizzoUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, indirizzoUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
}
