package it.epicode.energia.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.energia.impl.LoginRequest;
import it.epicode.energia.repository.ComuneRepository;
import it.epicode.energia.repository.ProvinciaRepository;
import it.epicode.energia.requests.InserisciProvinciaRequest;
import it.epicode.energia.requests.InserisciProvinciaRequest;
import it.epicode.energia.requests.ModificaProvinciaRequest;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class ProvinciaTest {
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	@Autowired
	ProvinciaRepository pr;
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("feciola");
		login.setPassword("xxxciao");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("babbollu");
		login.setPassword("xxxstoca");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	@Test
	void inserisciProvincia() {
		String url = "http://localhost:" + port + "/provincia/inserisci-provincia/";
		InserisciProvinciaRequest p = new InserisciProvinciaRequest();
		p.setProvincia("Prova");
		p.setRegione("Regione delle prove");
		p.setSigla("PP");
		//Not logged
		HttpEntity<InserisciProvinciaRequest> ProvinciaEntity = new HttpEntity<InserisciProvinciaRequest>(p);
		log.info("----------------inserisciProvincia" + url + "------POST");
		ResponseEntity<String> r = trt.exchange(url, HttpMethod.POST, ProvinciaEntity, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		//Admin
		HttpEntity<InserisciProvinciaRequest> ProvinciaAdmin = new HttpEntity<InserisciProvinciaRequest>(p, getAdminHeader());
		log.info("----------------inserisciProvincia" + url + "------POST");
		r = trt.exchange(url, HttpMethod.POST, ProvinciaAdmin, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		//User
		HttpEntity<InserisciProvinciaRequest> ProvinciaUser = new HttpEntity<InserisciProvinciaRequest>(p, getUserHeader());
		log.info("----------------inserisciProvincia" + url + "------POST");
		r = trt.exchange(url, HttpMethod.POST, ProvinciaUser, String.class);
		assertThat(r.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);

	}
	@Test
	void modificaProvincia() {
		String url = "http://localhost:" + port + "/provincia/modifica-provincia/1";
		ModificaProvinciaRequest request = new ModificaProvinciaRequest();
		request.setProvincia("Prova1");
		request.setRegione("Regione delle prove1");
		request.setSigla("PP1");
		HttpEntity<ModificaProvinciaRequest> provinciaEntity = new HttpEntity<ModificaProvinciaRequest>(request);
		log.info("--------------------mod-provincia--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.PUT, provinciaEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<ModificaProvinciaRequest> provinciaAdmin = new HttpEntity<ModificaProvinciaRequest>(request, getAdminHeader() );
		log.info("--------------------mod-provincia--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.PUT, provinciaAdmin, String.class);
				log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response2.toString());
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<ModificaProvinciaRequest> provinciaUser = new HttpEntity<ModificaProvinciaRequest>(request, getUserHeader() );
		log.info("--------------------mod-provincia--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.PUT, provinciaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaProvincia() {
		String url = "http://localhost:" + port + "/provincia/AQ";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<String> provinciaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, provinciaAdmin, String.class);
		log.info("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@" +response2.toString());
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<String> provinciaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, provinciaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetAllProvince() {
		String url = "http://localhost:" + port + "/provincia/";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> provinciaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, provinciaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> provinciaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, provinciaUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void GetProvinciaById() {
		String url = "http://localhost:" + port + "/provincia/SS";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> provinciaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, provinciaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> provinciaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, provinciaUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
}
