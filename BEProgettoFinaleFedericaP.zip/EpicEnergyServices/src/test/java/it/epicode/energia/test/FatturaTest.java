package it.epicode.energia.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.energia.impl.LoginRequest;
import it.epicode.energia.model.StatoFattura;
import it.epicode.energia.repository.FatturaRepository;
import it.epicode.energia.requests.InserisciFatturaRequest;
import it.epicode.energia.requests.ModificaFatturaRequest;
import it.epicode.energia.requests.getAnnoBetweenRequest;
import it.epicode.energia.requests.getFatturaByDataBetweenRequest;
import it.epicode.energia.requests.getRangeImportiBetweenRequest;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class FatturaTest {
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	@Autowired
	FatturaRepository fr;
	
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("feciola");
		login.setPassword("xxxciao");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("babbollu");
		login.setPassword("xxxstoca");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	@Test
	void inserisciFattura() {
		String url = "http://localhost:" + port + "/fattura/inserisci-fattura/";	
		InserisciFatturaRequest request = new InserisciFatturaRequest();
		request.setNumero(34561);
		request.setAnno(2019);
		request.setData("2022-04-10");
		request.setImporto(80000.00);
		request.setPartitaIva("BBB12334519757");
		request.setStato(StatoFattura.SALDATO);
		HttpEntity<InserisciFatturaRequest> fatturaEntity = new HttpEntity<InserisciFatturaRequest>(request);
		log.info("--------------------inserisci-fattura--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, fatturaEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<InserisciFatturaRequest> fatturaeAdmin = new HttpEntity<InserisciFatturaRequest>(request, getAdminHeader() );
		log.info("--------------------inserisci-fattura--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, fatturaeAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<InserisciFatturaRequest> fatturaUser = new HttpEntity<InserisciFatturaRequest>(request, getUserHeader() );
		log.info("--------------------inserisci-fattura--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, fatturaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void modificaFattura() {
		String url = "http://localhost:" + port + "/fattura/modifica-fattura/345";	
		ModificaFatturaRequest request = new ModificaFatturaRequest();
		request.setAnno(2019);
		request.setData("2022-04-10");
		request.setImporto(80000.00);
		request.setPartitaIva("BBB12334519757");
		request.setStato(StatoFattura.SALDATO);
		HttpEntity<ModificaFatturaRequest> fatturaEntity = new HttpEntity<ModificaFatturaRequest>(request);
		log.info("--------------------modifica-fattura--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.PUT, fatturaEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<ModificaFatturaRequest> fatturaAdmin = new HttpEntity<ModificaFatturaRequest>(request, getAdminHeader() );
		log.info("--------------------modifica-fattura--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.PUT, fatturaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<ModificaFatturaRequest> fatturaUser = new HttpEntity<ModificaFatturaRequest>(request, getUserHeader() );
		log.info("--------------------modifica-fattura--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.PUT, fatturaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaFattura() {
		String url = "http://localhost:" + port + "/fattura/567";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response.toString());
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> fatturaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, fatturaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> fatturaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, fatturaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetAllFatture() {
		String url = "http://localhost:" + port + "/fattura/";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> fatturaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, fatturaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> fatturaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, fatturaUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void GetFattureByNumero() {
		String url = "http://localhost:" + port + "/fattura/345";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> fatturaAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, fatturaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> fatturaUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, fatturaUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getAnnoFattura() {
		String url = "http://localhost:" + port + "/fattura/fattura-by-anno";	
		getAnnoBetweenRequest request = new getAnnoBetweenRequest();
		request.setAnnoDa(2020);
		request.setAnnoA(2022);
		HttpEntity<getAnnoBetweenRequest> fatturaEntity = new HttpEntity<getAnnoBetweenRequest>(request);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, fatturaEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<getAnnoBetweenRequest> fatturaAdmin = new HttpEntity<getAnnoBetweenRequest>(request, getAdminHeader() );
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, fatturaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<getAnnoBetweenRequest> fatturaUser = new HttpEntity<getAnnoBetweenRequest>(request, getUserHeader() );
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, fatturaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void getRangeImportiFatture() {
		String url = "http://localhost:" + port + "/fattura/fattura-by-anno";	
		getRangeImportiBetweenRequest request = new getRangeImportiBetweenRequest();
		HttpEntity<getRangeImportiBetweenRequest> fatturaEntity = new HttpEntity<getRangeImportiBetweenRequest>(request);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, fatturaEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<getRangeImportiBetweenRequest> fatturaAdmin = new HttpEntity<getRangeImportiBetweenRequest>(request, getAdminHeader() );
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, fatturaAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<getRangeImportiBetweenRequest> fatturaUser = new HttpEntity<getRangeImportiBetweenRequest>(request, getUserHeader() );
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, fatturaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void getFattureByData() {
		String url = "http://localhost:" + port + "/fattura/fattura-by-anno";	
		getFatturaByDataBetweenRequest request = new getFatturaByDataBetweenRequest();
		HttpEntity<getFatturaByDataBetweenRequest> fatturaEntity = new HttpEntity<getFatturaByDataBetweenRequest>(request);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, fatturaEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<getFatturaByDataBetweenRequest> fatturaAdmin = new HttpEntity<getFatturaByDataBetweenRequest>(request, getAdminHeader() );
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, fatturaAdmin, String.class);
		log.info("////////////////////////////" +response2.toString());
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<getFatturaByDataBetweenRequest> fatturaUser = new HttpEntity<getFatturaByDataBetweenRequest>(request, getUserHeader() );
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, fatturaUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
@Test
void GetAllFatturePaginate() {
	String url = "http://localhost:" + port + "/fattura/get-all-fatture-paginate";
	ResponseEntity<String> response = trt.getForEntity(url, String.class);
	assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

	HttpEntity<String> fatturaAdmin = new HttpEntity<String>(getAdminHeader());
	ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, fatturaAdmin, String.class);
	assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

	HttpEntity<String> fatturaUser = new HttpEntity<String>(getUserHeader());
	ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, fatturaUser, String.class);
	log.info("////////////////////////////" +response3.toString());
	assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
}
}
