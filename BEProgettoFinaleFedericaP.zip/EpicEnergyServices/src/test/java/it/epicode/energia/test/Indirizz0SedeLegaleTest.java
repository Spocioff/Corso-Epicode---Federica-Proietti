package it.epicode.energia.test;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.energia.impl.LoginRequest;

import it.epicode.energia.repository.IndirizzoSedeLegaleRepository;
import it.epicode.energia.requests.InserisciIndirizzoSedeLegaleRequest;
import it.epicode.energia.requests.ModificaIndirizzoSedeLegaleRequest;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class Indirizz0SedeLegaleTest {
	
	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	@Autowired
	IndirizzoSedeLegaleRepository islr;
	
	
	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("feciola");
		login.setPassword("xxxciao");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("babbollu");
		login.setPassword("xxxstoca");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	@Test
	void inserisciIndirizzo() {
		String url = "http://localhost:" + port + "/indirizzoSedeLegale/inserisci-indirizzo";
		InserisciIndirizzoSedeLegaleRequest request = new InserisciIndirizzoSedeLegaleRequest();	
		request.setVia("piazza delle vipere");
		request.setCivico(34);
		request.setLocalita("ROMA");
		request.setCap("00100");
		request.setPartitaIva("45634519757");
		request.setId_comune(1);
		HttpEntity<InserisciIndirizzoSedeLegaleRequest> indirizzoEntity = new HttpEntity<InserisciIndirizzoSedeLegaleRequest>(request);
		log.info("--------------------inserisci-indirizzo--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, indirizzoEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<InserisciIndirizzoSedeLegaleRequest> indirizzoAdmin = new HttpEntity<InserisciIndirizzoSedeLegaleRequest>(request, getAdminHeader() );
		log.info("--------------------inserisci-indirizzo--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, indirizzoAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<InserisciIndirizzoSedeLegaleRequest> indirizzoUser = new HttpEntity<InserisciIndirizzoSedeLegaleRequest>(request, getUserHeader() );
		log.info("--------------------inserisci-indirizzo--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, indirizzoUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void modificaIndirizzo() {
		String url = "http://localhost:" + port + "/indirizzoSedeLegale/modifica-indirizzo/2";
	ModificaIndirizzoSedeLegaleRequest request = new ModificaIndirizzoSedeLegaleRequest();
	request.setVia("piazza delle serpi");
	request.setCivico(43);
	request.setLocalita("CAGLIARI");
	request.setCap("09100");
	request.setPartitaIva("45634519757");
	request.setId_comune(1);
	HttpEntity<ModificaIndirizzoSedeLegaleRequest> indirizzoEntity = new HttpEntity<ModificaIndirizzoSedeLegaleRequest>(request);
	log.info("--------------------mod-indirizzo--------------------------" + url);
	ResponseEntity<String> response = trt.exchange(url, HttpMethod.PUT, indirizzoEntity, String.class);
	assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
	HttpEntity<ModificaIndirizzoSedeLegaleRequest> indirizzoAdmin = new HttpEntity<ModificaIndirizzoSedeLegaleRequest>(request, getAdminHeader() );
	log.info("--------------------mod-indirizzo--------------------------" + url);
	log.info("======Token Update=====" + getAdminToken());
	ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.PUT, indirizzoAdmin, String.class);
			log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response2.toString());
	assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	HttpEntity<ModificaIndirizzoSedeLegaleRequest> indirizzoUser = new HttpEntity<ModificaIndirizzoSedeLegaleRequest>(request, getUserHeader() );
	log.info("--------------------mod-indirizzo--------------------------" + url);
	log.info("======Token Update=====" + getUserToken());
	ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.PUT, indirizzoUser, String.class);
	assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaIndirizzo() {
		String url = "http://localhost:" + port + "/indirizzoSedeLegale/1";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response.toString());
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> indirizzoAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, indirizzoAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> indirizzoUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, indirizzoUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetAllIndirizzi() {
		String url = "http://localhost:" + port + "/indirizzoSedeLegale/";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> indirizzoAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, indirizzoAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> indirizzoUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, indirizzoUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void findIndirizzoById () {
		String url = "http://localhost:" + port + "/indirizzoSedeLegale/2";	
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> indirizzoAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, indirizzoAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> indirizzoUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, indirizzoUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
}
