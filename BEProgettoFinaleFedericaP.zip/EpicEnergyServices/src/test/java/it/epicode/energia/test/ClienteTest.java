package it.epicode.energia.test;

import static org.assertj.core.api.Assertions.assertThat;


import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import it.epicode.energia.impl.LoginRequest;
import it.epicode.energia.model.RagioneSociale;
import it.epicode.energia.repository.ClienteRepository;
import it.epicode.energia.requests.InserisciClienteRequest;
import it.epicode.energia.requests.ModificaClienteRequest;
import it.epicode.energia.requests.getDataInserimentoBetweenRequest;
import it.epicode.energia.requests.getDataUltimoContattoBetweenRequest;
import it.epicode.energia.requests.getFatturatoAnnualeBetweenRequest;
import it.epicode.energia.requests.getDataUltimoContattoBetweenRequest;
import it.epicode.energia.requests.getDataUltimoContattoBetweenRequest;
import it.epicode.energia.requests.getRangeImportiBetweenRequest;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Slf4j
public class ClienteTest {

	@Autowired
	TestRestTemplate trt;
	@LocalServerPort int port;
	@Autowired
	ClienteRepository cr;

	protected String getAdminToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("feciola");
		login.setPassword("xxxciao");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected String getUserToken() {
		String url = "http://localhost:" + port + "/api/auth/login/jwt";
		LoginRequest login = new LoginRequest();
		login.setUserName("babbollu");
		login.setPassword("xxxstoca");
		HttpEntity<LoginRequest> loginRequest = new HttpEntity<LoginRequest>(login);
		String jwt = trt.postForObject(url, loginRequest, String.class);
		return jwt;
	}
	protected HttpHeaders getAdminHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getAdminToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	protected HttpHeaders getUserHeader() {
		HttpHeaders header = new HttpHeaders();
		String jwt = getUserToken();
		header.set("Authorization", "Bearer " + jwt);
		return header;
	}
	@Test
	void inserisciCliente() {
		String url = "http://localhost:" + port + "/cliente/inserisci-cliente/";
		InserisciClienteRequest request = new InserisciClienteRequest();
		request.setNomeContatto("Gigio");
		request.setCognomeContatto("Gigino");
		request.setDataInserimento("2022-01-01");
		request.setDataUltimoContatto("2022-05-20");
		request.setEmailContatto("gigio@gmail.com");
		request.setFatturatoAnnuale(30000.00);
		request.setPartitaIva("1243235245");
		request.setPec("gigio@pec.it");
		request.setNumero(12245);
		request.setRagioneSociale(RagioneSociale.SRL);
		request.setTelefonoContatto("34509867659");
		request.setTelefono("06892843");
		request.setId_isl(1);
		request.setId_iso(1);
		HttpEntity<InserisciClienteRequest> clienteEntity = new HttpEntity<InserisciClienteRequest>(request);
		log.info("--------------------inserisci-cliente--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, clienteEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<InserisciClienteRequest> clienteAdmin = new HttpEntity<InserisciClienteRequest>(request, getAdminHeader() );
		log.info("--------------------inserisci-cliente--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<InserisciClienteRequest> clienteUser = new HttpEntity<InserisciClienteRequest>(request, getUserHeader() );
		log.info("--------------------inserisci-cliente--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void modificaCliente() {
		String url = "http://localhost:" + port + "/cliente/modifica/BBB12334519757";
		ModificaClienteRequest request = new ModificaClienteRequest();
		request.setNomeContatto("Gigiotto");
		request.setCognomeContatto("Giginetto");
		request.setDataInserimento("2021-02-01");
		request.setDataUltimoContatto("2022-04-23");
		request.setEmailContatto("gigiotto@gmail.com");
		request.setFatturatoAnnuale(30000.00);
		request.setPec("gigiotto@pec.it");
		request.setNumero(123);
		request.setRagioneSociale(RagioneSociale.SAS);
		request.setTelefonoContatto("34609867659");
		request.setTelefono("068928435");
		request.setId_iso(1);
		request.setId_isl(1);
		log.info(url);
		//	log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +cr.findById("BBB12334519757").toString());

		HttpEntity<ModificaClienteRequest> clienteEntity = new HttpEntity<ModificaClienteRequest>(request);
		log.info("--------------------mod-cliente--------------------------" + url);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.PUT, clienteEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<ModificaClienteRequest> clienteAdmin = new HttpEntity<ModificaClienteRequest>(request, getAdminHeader() );
		log.info("--------------------mod-cliente--------------------------" + url);
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.PUT, clienteAdmin, String.class);
				log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response2.toString());
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<ModificaClienteRequest> clienteUser = new HttpEntity<ModificaClienteRequest>(request, getUserHeader() );
		log.info("--------------------mod-cliente--------------------------" + url);
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.PUT, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void eliminaCliente() {
		String url = "http://localhost:" + port + "/cliente/86334519757";
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.DELETE, HttpEntity.EMPTY, String.class);
		log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA" +response.toString());
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.DELETE, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.DELETE, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void GetAllClienti() {
		String url = "http://localhost:" + port + "/cliente/";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, clienteUser, String.class);
		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void findClienteById () {
		String url = "http://localhost:" + port + "/cliente/BBB12334519757";	
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);

		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);

		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}

	@Test
	void getDataUltimoContatto() {
		String url = "http://localhost:" + port + "/cliente/data-ultimo-contatto-between";	
		getDataUltimoContattoBetweenRequest request = new getDataUltimoContattoBetweenRequest();
		request.setDataUltimoContattoDa("2020-01-01");
		request.setDataUltimoContattoA("2022-12-12");
		HttpEntity<getDataUltimoContattoBetweenRequest> clienteEntity = new HttpEntity<getDataUltimoContattoBetweenRequest>(request);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, clienteEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<getDataUltimoContattoBetweenRequest> clienteAdmin = new HttpEntity<getDataUltimoContattoBetweenRequest>(request, getAdminHeader() );
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<getDataUltimoContattoBetweenRequest> clienteUser = new HttpEntity<getDataUltimoContattoBetweenRequest>(request, getUserHeader() );
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);	
	}
	@Test
	void getNomeContattoContaining() {
		String url = "http://localhost:" + port + "/cliente/nome-containing/io";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, clienteUser, String.class);
//		log.info("////////////////////////////" +response3.toString());
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getFatturatoAnnuale() {
		String url = "http://localhost:" + port + "/cliente/fatturato-annuale";
		getFatturatoAnnualeBetweenRequest request = new getFatturatoAnnualeBetweenRequest();
		request.setFatturatoAnnualeDa(10.00);
		request.setFatturatoAnnualeA(10000000.00);
		HttpEntity<getFatturatoAnnualeBetweenRequest> clienteEntity = new HttpEntity<getFatturatoAnnualeBetweenRequest>(request);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, clienteEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<getFatturatoAnnualeBetweenRequest> clienteAdmin = new HttpEntity<getFatturatoAnnualeBetweenRequest>(request, getAdminHeader() );
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<getFatturatoAnnualeBetweenRequest> clienteUser = new HttpEntity<getFatturatoAnnualeBetweenRequest>(request, getUserHeader() );
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);
	}
	@Test
	void getDataInserimento() {
		String url = "http://localhost:" + port + "/cliente/data-inserimento";	
		getDataInserimentoBetweenRequest request = new getDataInserimentoBetweenRequest();
		request.setDataInserimentoDa("2020-01-01");
		request.setDataInserimentoA("2022-12-12");
		HttpEntity<getDataInserimentoBetweenRequest> clienteEntity = new HttpEntity<getDataInserimentoBetweenRequest>(request);
		ResponseEntity<String> response = trt.exchange(url, HttpMethod.POST, clienteEntity, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<getDataInserimentoBetweenRequest> clienteAdmin = new HttpEntity<getDataInserimentoBetweenRequest>(request, getAdminHeader() );
		log.info("======Token Update=====" + getAdminToken());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.POST, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<getDataInserimentoBetweenRequest> clienteUser = new HttpEntity<getDataInserimentoBetweenRequest>(request, getUserHeader() );
		log.info("======Token Update=====" + getUserToken());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.POST, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.FORBIDDEN);	
	}	
	@Test
	void getClientiFatturatoAnnualeDesc() {
		String url = "http://localhost:" + port + "/cliente/get-by-fatturato-annuale";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getClientiUltimoContattoDesc() {
		String url = "http://localhost:" + port + "/cliente/get-by-data-utimo-contatto";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
	@Test
	void getClientiDataInsermentoDesc() {
		String url = "http://localhost:" + port + "/cliente/get-by-data-inserimento";
		ResponseEntity<String> response = trt.getForEntity(url, String.class);
		assertThat(response.getStatusCode()).isEqualByComparingTo(HttpStatus.UNAUTHORIZED);
		HttpEntity<String> clienteAdmin = new HttpEntity<String>(getAdminHeader());
		ResponseEntity<String> response2 = trt.exchange(url, HttpMethod.GET, clienteAdmin, String.class);
		assertThat(response2.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
		HttpEntity<String> clienteUser = new HttpEntity<String>(getUserHeader());
		ResponseEntity<String> response3 = trt.exchange(url, HttpMethod.GET, clienteUser, String.class);
		assertThat(response3.getStatusCode()).isEqualByComparingTo(HttpStatus.OK);
	}
}
